# BBHunt — Automated Bug Bounty Recon Framework

A professional, corporate-grade automation pipeline for bug bounty hunting. Runs continuously, finds new assets 24/7, and alerts you the moment something interesting appears.

---

## Architecture

```
bbhunt/
├── bbhunt.sh              ← Main CLI entry point
├── setup.sh               ← One-command tool installer
├── cron_setup.sh          ← Set up 24/7 monitoring
├── config/
│   └── config.sh          ← ALL settings in one place
├── modules/
│   ├── subdomain.sh       ← Multi-source enumeration + wildcard detection
│   ├── monitor.sh         ← Diff + instant alerts on new assets
│   ├── scan.sh            ← httpx probing + tiered Nmap
│   ├── vuln.sh            ← Nuclei with FP reduction + re-verification
│   ├── visual.sh          ← Screenshots + tech stack
│   └── notify.sh          ← Telegram / Discord / Slack
└── utils/
    ├── helpers.sh          ← Logging, colors, common functions
    └── report.py           ← Professional HTML dashboard
```

---

## Quick Start

```bash
# 1. Clone / download bbhunt folder
cd bbhunt

# 2. Install all tools (Ubuntu/Kali/macOS)
chmod +x setup.sh && ./setup.sh

# 3. Configure (add your notification tokens)
nano config/config.sh

# 4. Run full recon on a target
chmod +x bbhunt.sh
./bbhunt.sh -d target.com

# 5. Set up 24/7 monitoring
./cron_setup.sh
```

---

## Configuration (`config/config.sh`)

### Notifications (at least one required for alerts)

| Variable | Description |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Bot token from @BotFather |
| `TELEGRAM_CHAT_ID` | Your chat or group ID |
| `DISCORD_WEBHOOK_URL` | Server → Edit Channel → Integrations → Webhooks |
| `SLACK_WEBHOOK_URL` | apps.slack.com → Incoming Webhooks |

### Key settings for accuracy

```bash
# Require 2+ tools to find a subdomain (reduces FPs significantly)
MIN_TOOL_CORROBORATION=2

# Only alert on these severity levels
NUCLEI_SEVERITIES="critical,high,medium"

# Re-verify critical/high before alerting (removes false positives)
NUCLEI_VERIFY=true
```

---

## Usage Examples

```bash
# Full pipeline (recommended)
./bbhunt.sh -d target.com

# Only subdomain enumeration
./bbhunt.sh -d target.com -m subdomains

# Subdomain + HTTP probing + port scan (no vuln scan)
./bbhunt.sh -d target.com -m subdomains,scan

# Vuln scan only (assumes scans already ran)
./bbhunt.sh -d target.com -m vulns

# Monitoring pass — diff all tracked domains
./bbhunt.sh --monitor

# Regenerate HTML report from existing data
./bbhunt.sh -d target.com --report-only

# Debug mode
./bbhunt.sh -d target.com -v
```

---

## What each module does

### `subdomains` — Multi-source enumeration
- Runs Subfinder, Amass, Assetfinder, Findomain, crt.sh in parallel
- Detects wildcard DNS and removes false resolutions
- Validates every subdomain via `dnsx` (real DNS resolution)
- Optional: require 2+ tools to corroborate a subdomain (set `MIN_TOOL_CORROBORATION=2`)

### `monitor` — New asset detection
- Diffs current results against the previous snapshot
- Instantly alerts on new subdomains via all configured channels
- Runs a quick nuclei scan on new assets immediately
- Checks removed subdomains for subdomain takeover potential

### `scan` — Smart port scanning
- Probes all subdomains with `httpx` (status codes, titles, tech, IPs)
- Filters dead hosts before scanning (never wastes time)
- Quick top-1000 Nmap scan first; full -p- only on interesting hosts
- Flags admin panels, APIs, dev/staging environments automatically

### `vulns` — Nuclei with FP reduction
- Phase 1: Targeted scan (exposures, misconfigs, default-creds, panels)
- Phase 2: CVE templates (critical/high only)
- Phase 3: Custom templates (if you add your own)
- Removes known high-FP templates automatically
- **Re-verifies all critical/high findings** with 3 retries before alerting

### `visual` — Screenshot + tech fingerprinting
- Screenshots every alive web server with `gowitness`
- Identifies high-value targets: admin panels, API docs, dev envs, monitoring
- Scores each URL by interest level
- Generates browsable HTML screenshot report

---

## False Positive Reduction

This framework is specifically designed to minimize noise:

1. **Subdomain FP reduction**: Wildcard detection removes cloud CDN noise
2. **DNS validation**: Every subdomain must resolve (dnsx)
3. **Corroboration**: Optionally require 2+ tools to find a subdomain
4. **Nuclei template exclusions**: Removes known high-FP templates (info-disclosure, generic tokens, header checkers)
5. **Nuclei re-verification**: Critical/high findings are re-probed 3 times before alerting
6. **Content filtering**: Pages with parking/default titles filtered from interesting list

---

## Output Structure

```
~/.bbhunt/results/<domain>/
├── subdomains/
│   ├── raw/               ← Per-tool raw outputs
│   ├── combined_raw.txt   ← Merged before DNS validation
│   ├── final.txt          ← DNS-validated, wildcard-free list
│   └── all_new_ever.txt   ← Running log of all newly discovered assets
├── scans/
│   ├── httpx_full.json    ← Full httpx output with all metadata
│   ├── alive.txt          ← Live HTTP hosts
│   ├── interesting.txt    ← High-interest URLs
│   └── nmap/              ← Per-host nmap scan files
├── vulns/
│   ├── all_findings_raw.json      ← Everything nuclei found
│   ├── all_findings_filtered.json ← After FP removal
│   └── verified_findings.json    ← Final verified findings
├── screenshots/
│   ├── screens/           ← PNG screenshots
│   ├── gowitness_report.html
│   ├── tech_summary.txt   ← Technology stack breakdown
│   └── high_value_targets.txt
├── diffs/
│   ├── snapshot_*.txt     ← Historical snapshots (last 30)
│   ├── new_*.txt          ← New subdomains per run
│   └── latest_diff.json
├── reports/
│   └── report.html        ← Professional HTML dashboard
└── logs/
    └── bbhunt_*.log       ← Timestamped run logs
```

---

## What you need to do manually (I can't automate these)

### 1. Install tools
Run `./setup.sh` — this handles everything automatically.

### 2. Add API keys for subfinder
Free tier keys massively improve subdomain discovery. Add them to:
`~/.config/subfinder/provider-config.yaml`

Services with free API keys:
- **VirusTotal** — virustotal.com (free account)
- **SecurityTrails** — securitytrails.com (free: 50 queries/month)
- **Shodan** — shodan.io (paid, but ~$60 one-time)
- **Censys** — censys.io (free research account)
- **BinaryEdge** — binaryedge.io (free tier)
- **Chaos** — chaos.projectdiscovery.io (free, excellent)

### 3. Configure notifications
Edit `config/config.sh`:
- **Telegram** (recommended): Create a bot via @BotFather, get your chat ID from @userinfobot
- **Discord**: Create a webhook in your Discord server
- **Slack**: Create an Incoming Webhook app

### 4. Verify you have scope permission
This tool is powerful. Only run it against:
- Bug bounty programs where you're authorized
- Domains in the program's scope
- Your own infrastructure

---

## Monitoring setup (24/7)

```bash
./cron_setup.sh
```

This sets up an automated cron job that:
1. Re-enumerates all tracked domains
2. Diffs against previous results
3. Alerts you on new subdomains
4. Immediately nuclei-scans new assets
5. Generates an updated report

You'll receive notifications like:
```
🔎 New Attack Surface — target.com
New subdomains: 3
• staging-api.target.com
• dev-portal.target.com
• admin2.target.com
```

---

## Tips for finding bugs faster

1. **Focus on new assets first** — they're untested
2. **Check `high_value_targets.txt` immediately** — scored by interest
3. **401/403 responses** are worth manual probing — often bypass-able
4. **Staging/dev environments** frequently have weaker auth
5. **API documentation** (Swagger/Redoc) reveals endpoints to test
6. **Admin panels** — try default credentials first
7. Check `tech_summary.txt` — old WordPress/Joomla installs are goldmines
