#!/usr/bin/env bash
# bbhunt.sh — Professional Bug Bounty Automation Framework
# Usage: ./bbhunt.sh -d target.com [-m all|subdomains|scan|vulns|visual|monitor]
#        ./bbhunt.sh -d target.com -m all --notify
#        ./bbhunt.sh --monitor  (run scheduled monitoring for all targets)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Source dependencies ───────────────────────────────────────────────────────
source "${SCRIPT_DIR}/config/config.sh"
source "${SCRIPT_DIR}/utils/helpers.sh"
source "${SCRIPT_DIR}/modules/notify.sh"
source "${SCRIPT_DIR}/modules/subdomain.sh"
source "${SCRIPT_DIR}/modules/monitor.sh"
source "${SCRIPT_DIR}/modules/scan.sh"
source "${SCRIPT_DIR}/modules/vuln.sh"
source "${SCRIPT_DIR}/modules/visual.sh"

# ─── Defaults ─────────────────────────────────────────────────────────────────
DOMAIN=""
MODULES="all"
MONITOR_MODE=false
SKIP_TOOL_CHECK=false
VERBOSE=false
REPORT_ONLY=false

# ─── Argument parsing ─────────────────────────────────────────────────────────
usage() {
  cat << EOF
${BOLD}BBHunt — Automated Bug Bounty Recon${RESET}

Usage:
  $(basename "$0") -d <domain> [options]
  $(basename "$0") --monitor              Run monitoring pass for all tracked domains

Options:
  -d, --domain <domain>    Target domain (required unless --monitor)
  -m, --modules <list>     Comma-separated modules to run (default: all)
                           Choices: subdomains, scan, vulns, visual, monitor, report
  --skip-tool-check        Skip tool availability check
  --report-only            Just regenerate HTML report from existing data
  -v, --verbose            Enable debug logging
  -h, --help               Show this help

Examples:
  ./bbhunt.sh -d example.com
  ./bbhunt.sh -d example.com -m subdomains,scan,vulns
  ./bbhunt.sh -d example.com -m subdomains --skip-tool-check
  ./bbhunt.sh --monitor
EOF
  exit 0
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -d|--domain)       DOMAIN="$2";           shift 2 ;;
    -m|--modules)      MODULES="$2";          shift 2 ;;
    --monitor)         MONITOR_MODE=true;     shift ;;
    --skip-tool-check) SKIP_TOOL_CHECK=true;  shift ;;
    --report-only)     REPORT_ONLY=true;      shift ;;
    -v|--verbose)      VERBOSE=true; export DEBUG=1; shift ;;
    -h|--help)         usage ;;
    *) log_error "Unknown argument: $1"; usage ;;
  esac
done

# ─── Monitor mode: check all tracked domains ─────────────────────────────────
if [[ "$MONITOR_MODE" == "true" ]]; then
  print_banner
  log_section "Monitoring Mode — all tracked domains"
  tracked="${OUTPUT_BASE}/.tracked_domains"
  if [[ ! -f "$tracked" ]]; then
    log_error "No tracked domains found. Run a full scan first."
    exit 1
  fi
  while IFS= read -r tracked_domain; do
    [[ -z "$tracked_domain" ]] && continue
    log_section "Monitoring: ${tracked_domain}"
    outdir="${OUTPUT_BASE}/$(safe_name "$tracked_domain")"
    if [[ -d "$outdir/subdomains" ]]; then
      # Re-run subdomain enum
      run_subdomain_enum "$tracked_domain" "$outdir"
      # Diff + notify
      run_monitor "$tracked_domain" "$outdir"
      # Regenerate report
      python3 "${SCRIPT_DIR}/utils/report.py" "$outdir" "$tracked_domain"
    fi
  done < "$tracked"
  log_ok "Monitoring pass complete."
  exit 0
fi

# ─── Validate domain ─────────────────────────────────────────────────────────
if [[ -z "$DOMAIN" ]]; then
  log_error "Domain is required. Use -d <domain>"
  usage
fi

# Strip protocol if given
DOMAIN=$(echo "$DOMAIN" | sed 's|^https\?://||' | sed 's|/.*||' | tr '[:upper:]' '[:lower:]')

# ─── Setup output dirs ────────────────────────────────────────────────────────
OUTDIR="${OUTPUT_BASE}/$(safe_name "$DOMAIN")"
LOGFILE="${OUTDIR}/logs/bbhunt_$(date +%Y%m%d_%H%M%S).log"
mkdir -p "${OUTDIR}/logs"

# Tee all output to logfile
exec > >(tee -a "$LOGFILE") 2>&1

print_banner
log_info "Target:  ${BOLD}${DOMAIN}${RESET}"
log_info "Modules: ${BOLD}${MODULES}${RESET}"
log_info "Output:  ${BOLD}${OUTDIR}${RESET}"
log_info "Log:     ${BOLD}${LOGFILE}${RESET}"
echo ""

make_output_dirs "$OUTDIR"

# Track this domain for monitoring
echo "$DOMAIN" | anew "${OUTPUT_BASE}/.tracked_domains" > /dev/null 2>&1 || \
  { mkdir -p "$OUTPUT_BASE" && echo "$DOMAIN" >> "${OUTPUT_BASE}/.tracked_domains"; }

# ─── Tool check ───────────────────────────────────────────────────────────────
if [[ "$SKIP_TOOL_CHECK" != "true" ]]; then
  check_required_tools || { log_error "Install missing tools first. See setup.sh"; exit 1; }
fi

# ─── Report-only shortcut ─────────────────────────────────────────────────────
if [[ "$REPORT_ONLY" == "true" ]]; then
  log_info "Regenerating HTML report..."
  python3 "${SCRIPT_DIR}/utils/report.py" "$OUTDIR" "$DOMAIN"
  log_ok "Report: ${OUTDIR}/reports/report.html"
  exit 0
fi

# ─── Parse module list ────────────────────────────────────────────────────────
run_module() {
  local mod="$1"
  [[ "$MODULES" == "all" ]] && return 0
  echo "$MODULES" | tr ',' '\n' | grep -qx "$mod"
}

# ─── START TIME ───────────────────────────────────────────────────────────────
START_TS=$(date +%s)
log_section "Starting BBHunt — $(date)"

# ─── MODULE: Subdomain enumeration ───────────────────────────────────────────
if run_module subdomains || [[ "$MODULES" == "all" ]]; then
  run_subdomain_enum "$DOMAIN" "$OUTDIR"
  sleep "$INTER_MODULE_SLEEP"
fi

# ─── MODULE: Monitor (diff against previous) ─────────────────────────────────
if run_module monitor || [[ "$MODULES" == "all" ]]; then
  run_monitor "$DOMAIN" "$OUTDIR"
  sleep "$INTER_MODULE_SLEEP"
fi

# ─── MODULE: HTTP probe + port scanning ──────────────────────────────────────
if run_module scan || [[ "$MODULES" == "all" ]]; then
  run_scan "$DOMAIN" "$OUTDIR"
  sleep "$INTER_MODULE_SLEEP"
fi

# ─── MODULE: Vulnerability scanning ─────────────────────────────────────────
if run_module vulns || [[ "$MODULES" == "all" ]]; then
  run_vuln_scan "$DOMAIN" "$OUTDIR"
  sleep "$INTER_MODULE_SLEEP"
fi

# ─── MODULE: Visual recon ────────────────────────────────────────────────────
if run_module visual || [[ "$MODULES" == "all" ]]; then
  run_visual_recon "$DOMAIN" "$OUTDIR"
  sleep "$INTER_MODULE_SLEEP"
fi

# ─── REPORT GENERATION ───────────────────────────────────────────────────────
log_section "Generating HTML Report"
python3 "${SCRIPT_DIR}/utils/report.py" "$OUTDIR" "$DOMAIN"

# ─── FINAL SUMMARY ───────────────────────────────────────────────────────────
END_TS=$(date +%s)
ELAPSED=$(( END_TS - START_TS ))
MINS=$(( ELAPSED / 60 ))
SECS=$(( ELAPSED % 60 ))

log_section "BBHunt Complete"
echo -e "  ${BOLD}Domain:${RESET}      ${DOMAIN}"
echo -e "  ${BOLD}Subdomains:${RESET}  $(count_lines "${OUTDIR}/subdomains/final.txt" 2>/dev/null || echo 0)"
echo -e "  ${BOLD}Alive Hosts:${RESET} $(count_lines "${OUTDIR}/scans/alive.txt" 2>/dev/null || echo 0)"
echo -e "  ${BOLD}Findings:${RESET}    $(count_lines "${OUTDIR}/vulns/verified_findings.json" 2>/dev/null || echo 0)"
echo -e "  ${BOLD}Report:${RESET}      ${OUTDIR}/reports/report.html"
echo -e "  ${BOLD}Time:${RESET}        ${MINS}m ${SECS}s"
echo ""

# Final notification
notify "scan_done" "BBHunt Scan Complete — ${DOMAIN}" \
  "Subdomains: $(count_lines "${OUTDIR}/subdomains/final.txt" 2>/dev/null || echo 0)
Alive hosts: $(count_lines "${OUTDIR}/scans/alive.txt" 2>/dev/null || echo 0)
Findings: $(count_lines "${OUTDIR}/vulns/verified_findings.json" 2>/dev/null || echo 0)
Time: ${MINS}m ${SECS}s"

log_ok "Happy Hacking! 🎯"
