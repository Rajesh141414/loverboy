#!/usr/bin/env bash
# config.sh — Master configuration for BBHunt
# Edit this file before running. All settings centralized here.

# ─── Notification channels ────────────────────────────────────────────────────
# OPTIONAL — notifications are only sent for CRITICAL and HIGH vulnerabilities.
# New subdomains and scan completions are NOT notified — everything goes in the
# HTML report which you check manually when you run a scan.
# Leave all empty to disable notifications entirely.
TELEGRAM_BOT_TOKEN=""
TELEGRAM_CHAT_ID=""
DISCORD_WEBHOOK_URL=""
SLACK_WEBHOOK_URL=""

# ─── Output base directory ────────────────────────────────────────────────────
OUTPUT_BASE="${HOME}/.bbhunt/results"

# ─── Subdomain enumeration settings ──────────────────────────────────────────
# Number of parallel goroutines for subfinder
SUBFINDER_THREADS=100
# Amass timeout per enumeration (seconds)
AMASS_TIMEOUT=300
# Whether to run amass (slower but thorough)
RUN_AMASS=true
# Whether to run assetfinder
RUN_ASSETFINDER=true
# Whether to run findomain
RUN_FINDOMAIN=true
# DNS resolver file (leave empty to use system defaults + public resolvers)
RESOLVERS_FILE="${HOME}/.bbhunt/resolvers.txt"
# dnsx threads for DNS validation
DNSX_THREADS=200
# Minimum number of tools that must find a subdomain to include it (1 = any)
# Set to 2 to require corroboration — reduces FPs significantly
MIN_TOOL_CORROBORATION=1

# ─── HTTP probing settings ────────────────────────────────────────────────────
HTTPX_THREADS=100
HTTPX_TIMEOUT=15
HTTPX_RATE_LIMIT=150     # requests per second
# Status codes considered alive (comma-separated)
ALIVE_STATUS_CODES="200,201,204,301,302,307,308,401,403,405,500,503"
# Exclude these status codes from interesting targets
BORING_STATUS_CODES="400,404"

# ─── Port scanning settings ──────────────────────────────────────────────────
# Quick scan ports (top ports for fast triage)
NMAP_QUICK_PORTS="top-1000"
# Full scan only triggered when interesting ports found in quick scan
INTERESTING_PORTS="8080,8443,8888,9090,9200,9300,6379,27017,3306,5432,3389,5900,2375,4848,7001,8161,61616"
# Nmap timing template (0-5, 3=normal, 4=aggressive)
NMAP_TIMING=3
# Max parallel nmap processes
NMAP_PARALLEL=5
# Use masscan for initial fast sweep (requires root)
USE_MASSCAN=false
MASSCAN_RATE=1000

# ─── Nuclei settings ─────────────────────────────────────────────────────────
NUCLEI_THREADS=50
NUCLEI_RATE_LIMIT=150      # requests per second
NUCLEI_TIMEOUT=10
NUCLEI_RETRIES=1
# Severities to scan for
NUCLEI_SEVERITIES="critical,high,medium"
# Template tags to focus on (reduces FPs vs running all)
NUCLEI_TAGS="exposure,misconfig,takeover,cve,default-login,panel"
# Tags to EXCLUDE (high FP rate)
NUCLEI_EXCLUDE_TAGS="dos,fuzzing,generic"
# Path to custom nuclei templates (leave empty to skip)
CUSTOM_TEMPLATES_DIR=""
# Re-verify findings before alerting (recommended — reduces FPs)
NUCLEI_VERIFY=true
NUCLEI_VERIFY_RETRIES=3

# ─── Screenshot settings ─────────────────────────────────────────────────────
GOWITNESS_THREADS=20
GOWITNESS_TIMEOUT=10
# Screenshot resolution
GOWITNESS_RESOLUTION="1440,900"

# ─── Tech detection ───────────────────────────────────────────────────────────
# httpx has built-in tech detection; webanalyze adds depth
USE_WEBANALYZE=true

# ─── Monitoring settings ──────────────────────────────────────────────────────
# How many hours before a re-scan is considered fresh enough to skip
RESCAN_COOLDOWN_HOURS=20
# Send notification even if no new findings (heartbeat) — disabled by default
HEARTBEAT_NOTIFY=false

# ─── Rate limiting ────────────────────────────────────────────────────────────
# Sleep between module runs (seconds) — prevents hammering target
INTER_MODULE_SLEEP=2
RATE_SLEEP=0.3

# ─── False positive reduction ────────────────────────────────────────────────
# Skip subdomains whose HTTP title matches these patterns (likely parking pages)
FP_TITLE_PATTERNS="Domain for sale|This domain|Parked|Under construction|Default Web|Welcome to nginx|IIS Windows Server|Apache2 Ubuntu Default"
# Minimum content length to be considered an interesting response
MIN_CONTENT_LENGTH=200

# ─── crt.sh scraping ─────────────────────────────────────────────────────────
CRTSH_TIMEOUT=30
CRTSH_RETRIES=3

# ─── Wordlists (for optional active fuzzing) ─────────────────────────────────
SUBDOMAIN_WORDLIST="/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"

# ─── Report settings ─────────────────────────────────────────────────────────
REPORT_TITLE="BBHunt Recon Report"
OPEN_REPORT_AFTER=false
