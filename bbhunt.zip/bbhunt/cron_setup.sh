#!/usr/bin/env bash
# cron_setup.sh — Configure automated monitoring via cron
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils/helpers.sh"

BBHUNT="${SCRIPT_DIR}/bbhunt.sh"
LOG_DIR="${HOME}/.bbhunt/cron_logs"
mkdir -p "$LOG_DIR"

print_banner
log_section "Cron Job Setup"

echo -e "Select monitoring schedule:"
echo -e "  ${CYAN}1${RESET}) Every 6 hours  (intensive — recommended for active programs)"
echo -e "  ${CYAN}2${RESET}) Every 12 hours (balanced)"
echo -e "  ${CYAN}3${RESET}) Every 24 hours (lightweight)"
echo -e "  ${CYAN}4${RESET}) Custom (enter cron expression)"
echo -n "Choice [1-4]: "
read -r choice

case "$choice" in
  1) CRON_EXPR="0 */6 * * *";   DESC="every 6 hours" ;;
  2) CRON_EXPR="0 */12 * * *";  DESC="every 12 hours" ;;
  3) CRON_EXPR="0 2 * * *";     DESC="daily at 2:00 AM" ;;
  4)
     echo -n "Enter cron expression (e.g. '0 */8 * * *'): "
     read -r CRON_EXPR
     DESC="custom: ${CRON_EXPR}"
     ;;
  *) log_error "Invalid choice"; exit 1 ;;
esac

CRON_CMD="${CRON_EXPR} /usr/bin/env bash ${BBHUNT} --monitor >> ${LOG_DIR}/monitor_\$(date +\\%Y\\%m\\%d).log 2>&1"

# Install cron job
(crontab -l 2>/dev/null | grep -v "bbhunt" ; echo "$CRON_CMD") | crontab -

log_ok "Cron job installed: ${DESC}"
log_info "Cron entry: ${CRON_CMD}"
log_info "Logs will appear in: ${LOG_DIR}/"

echo ""
log_info "To view current crontab: ${CYAN}crontab -l${RESET}"
log_info "To remove monitoring:    ${CYAN}crontab -l | grep -v bbhunt | crontab -${RESET}"
echo ""

# Also create a simple systemd timer if available (more reliable than cron)
if command -v systemctl &>/dev/null && [[ -d /etc/systemd/user ]]; then
  echo -n "Also install systemd timer for reliability? [y/N]: "
  read -r install_systemd
  if [[ "$install_systemd" =~ ^[Yy]$ ]]; then
    _install_systemd_timer
  fi
fi

log_ok "Monitoring setup complete!"

_install_systemd_timer() {
  local service_file="${HOME}/.config/systemd/user/bbhunt-monitor.service"
  local timer_file="${HOME}/.config/systemd/user/bbhunt-monitor.timer"
  mkdir -p "${HOME}/.config/systemd/user"

  cat > "$service_file" << SVCEOF
[Unit]
Description=BBHunt Bug Bounty Monitoring
After=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/env bash ${BBHUNT} --monitor
StandardOutput=append:${LOG_DIR}/monitor.log
StandardError=append:${LOG_DIR}/monitor.log

[Install]
WantedBy=default.target
SVCEOF

  # Parse cron to OnCalendar (approximate)
  local interval
  case "$choice" in
    1) interval="*:0/6" ;;
    2) interval="*:0/12" ;;
    3) interval="*-*-* 02:00:00" ;;
    *) interval="*:0/12" ;;
  esac

  cat > "$timer_file" << TIMEREOF
[Unit]
Description=BBHunt Monitoring Timer

[Timer]
OnCalendar=${interval}
Persistent=true

[Install]
WantedBy=timers.target
TIMEREOF

  systemctl --user daemon-reload
  systemctl --user enable bbhunt-monitor.timer
  systemctl --user start bbhunt-monitor.timer

  log_ok "Systemd timer installed and started."
  log_info "Check status: systemctl --user status bbhunt-monitor.timer"
}
