#!/usr/bin/env bash
# monitor.sh — Subdomain monitoring, diffing, and new-asset alerting

run_monitor() {
  local domain="$1"
  local outdir="$2"
  local current_file="${outdir}/subdomains/final.txt"
  local diff_dir="${outdir}/diffs"
  mkdir -p "$diff_dir"

  log_section "Monitoring — ${domain}"

  # Find the most recent previous snapshot
  local prev_file
  prev_file=$(ls -t "${diff_dir}"/snapshot_*.txt 2>/dev/null | head -1) || true

  if [[ -z "$prev_file" ]]; then
    log_info "First run — saving baseline snapshot, nothing to diff."
    _save_snapshot "$current_file" "$diff_dir"
    return 0
  fi

  log_info "Previous snapshot: $(basename "$prev_file")"
  log_info "Previous count: $(count_lines "$prev_file")"
  log_info "Current count:  $(count_lines "$current_file")"

  # ─── Diff: new subdomains ─────────────────────────────────────────────────
  local new_file="${diff_dir}/new_$(date +%Y%m%d_%H%M%S).txt"
  local removed_file="${diff_dir}/removed_$(date +%Y%m%d_%H%M%S).txt"

  comm -23 \
    <(sort "$current_file") \
    <(sort "$prev_file") \
    > "$new_file"

  comm -23 \
    <(sort "$prev_file") \
    <(sort "$current_file") \
    > "$removed_file"

  local new_count removed_count
  new_count=$(count_lines "$new_file")
  removed_count=$(count_lines "$removed_file")

  if [[ $new_count -gt 0 ]]; then
    log_success "${new_count} NEW subdomain(s) discovered since last scan!"
    cat "$new_file" | while read -r sub; do
      log_success "  + ${sub}"
    done

    # Save to a persistent "all new" log — visible in the HTML report
    cat "$new_file" >> "${outdir}/subdomains/all_new_ever.txt"
    dedup_file "${outdir}/subdomains/all_new_ever.txt"

    # Queue new subdomains for HTTP probe so they appear in the next report
    log_info "Quick HTTP probe on new subdomains..."
    _quick_probe_new "$new_file" "${outdir}" "$domain"
  else
    log_info "No new subdomains found since last scan."
  fi

  if [[ $removed_count -gt 0 ]]; then
    log_warn "${removed_count} subdomain(s) no longer resolving (logged for review):"
    cat "$removed_file" | while read -r sub; do
      log_warn "  - ${sub}"
    done
    # Still check for takeovers — logged to file, no push notification
    _check_subdomain_takeover "$removed_file" "$outdir"
  fi

  # Save new snapshot
  _save_snapshot "$current_file" "$diff_dir"

  # Write diff summary JSON
  _write_diff_json "$domain" "$new_file" "$removed_file" "$outdir"
}

# ─── Save a timestamped snapshot ─────────────────────────────────────────────
_save_snapshot() {
  local src="$1"
  local diff_dir="$2"
  local snap="${diff_dir}/snapshot_$(date +%Y%m%d_%H%M%S).txt"
  cp "$src" "$snap"
  log_info "Snapshot saved: $(basename "$snap")"

  # Keep only last 30 snapshots
  ls -t "${diff_dir}"/snapshot_*.txt 2>/dev/null | tail -n +31 | xargs rm -f || true
}

# ─── Quick HTTP probe on newly-found subdomains ───────────────────────────────
_quick_probe_new() {
  local new_file="$1"
  local outdir="$2"
  local domain="$3"
  local quick_alive="${outdir}/scans/new_alive_quick.txt"

  if check_tool httpx; then
    httpx -l "$new_file" \
      -silent \
      -threads 50 \
      -timeout 10 \
      -status-code \
      -title \
      -tech-detect \
      -mc "$ALIVE_STATUS_CODES" \
      -o "$quick_alive" 2>/dev/null || true

    if [[ -s "$quick_alive" ]]; then
      log_success "New alive hosts:"
      while IFS= read -r line; do
        log_success "  $line"
      done < "$quick_alive"

      # Fire nuclei on new assets immediately
      if check_tool nuclei; then
        log_info "Running nuclei on new assets..."
        local new_vulns="${outdir}/vulns/new_asset_nuclei_$(date +%Y%m%d_%H%M%S).txt"
        awk '{print $1}' "$quick_alive" | nuclei \
          -t "$HOME/nuclei-templates" \
          -tags "$NUCLEI_TAGS" \
          -exclude-tags "$NUCLEI_EXCLUDE_TAGS" \
          -severity "$NUCLEI_SEVERITIES" \
          -rate-limit "$NUCLEI_RATE_LIMIT" \
          -timeout "$NUCLEI_TIMEOUT" \
          -retries "$NUCLEI_RETRIES" \
          -silent \
          -o "$new_vulns" 2>/dev/null || true

        if [[ -s "$new_vulns" ]]; then
          log_success "Nuclei findings on new assets (saved to report):"
          while IFS= read -r finding; do
            log_success "  $finding"
            # No push notification — findings are logged and visible in HTML report
          done < "$new_vulns"
        fi
      fi
    fi
  fi
}

# ─── Check if removed subdomains are takeover candidates ─────────────────────
_check_subdomain_takeover() {
  local removed_file="$1"
  local outdir="$2"

  if ! check_tool nuclei; then return; fi

  log_info "Checking removed subdomains for takeover potential..."
  local takeover_out="${outdir}/vulns/takeover_candidates.txt"

  # Use nuclei's subdomain takeover templates
  nuclei -l "$removed_file" \
    -t "$HOME/nuclei-templates/http/takeovers/" \
    -silent \
    -o "$takeover_out" 2>/dev/null || true

  if [[ -s "$takeover_out" ]]; then
    log_success "POTENTIAL SUBDOMAIN TAKEOVERS FOUND — check ${takeover_out}"
    while IFS= read -r line; do
      log_success "  $line"
      # Logged to verified_findings for the report — no push notification
    done < "$takeover_out"
  fi
}

# ─── Parse nuclei output line and send targeted notification ─────────────────
_parse_and_notify_nuclei_finding() {
  local line="$1"
  # Nuclei output format: [timestamp] [template-id] [severity] [url] [...]
  local template severity target
  template=$(echo "$line" | grep -oP '(?<=\[)[^\]]+(?=\])' | sed -n '2p')
  severity=$(echo "$line" | grep -oP '(?<=\[)[^\]]+(?=\])' | sed -n '3p')
  target=$(echo "$line" | grep -oP 'https?://[^ ]+' | head -1)

  [[ -z "$target" ]] && return

  local sev_key="vuln_$(echo "$severity" | tr '[:upper:]' '[:lower:]')"
  notify_vuln "$severity" "${template:-unknown}" "$target"
}

# ─── Write diff JSON summary ──────────────────────────────────────────────────
_write_diff_json() {
  local domain="$1"
  local new_file="$2"
  local removed_file="$3"
  local outdir="$4"

  python3 - << PYEOF
import json, datetime

def read_lines(f):
    try:
        with open(f) as fh:
            return [l.strip() for l in fh if l.strip()]
    except:
        return []

data = {
    "domain": "$domain",
    "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
    "new": read_lines("$new_file"),
    "removed": read_lines("$removed_file")
}

out = "$outdir/diffs/latest_diff.json"
with open(out, "w") as fh:
    json.dump(data, fh, indent=2)
print(f"Diff JSON written: {out}")
PYEOF
}
