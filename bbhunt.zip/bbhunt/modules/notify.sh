#!/usr/bin/env bash
# notify.sh — Multi-channel notification system

# ─── Send to Telegram ─────────────────────────────────────────────────────────
notify_telegram() {
  local message="$1"
  [[ -z "$TELEGRAM_BOT_TOKEN" || -z "$TELEGRAM_CHAT_ID" ]] && return 0

  local escaped
  # Telegram MarkdownV2 requires escaping special chars
  escaped=$(echo "$message" | sed 's/[_*[\]()~`>#+\-=|{}.!]/\\&/g')

  curl -s -X POST \
    "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -H "Content-Type: application/json" \
    -d "{
      \"chat_id\": \"${TELEGRAM_CHAT_ID}\",
      \"text\": \"${escaped}\",
      \"parse_mode\": \"MarkdownV2\",
      \"disable_web_page_preview\": true
    }" > /dev/null 2>&1 && log_ok "Telegram notification sent" || log_warn "Telegram notification failed"
}

# ─── Send to Discord ──────────────────────────────────────────────────────────
notify_discord() {
  local message="$1"
  local color="${2:-3447003}"   # blue by default; 15158332=red for critical
  [[ -z "$DISCORD_WEBHOOK_URL" ]] && return 0

  local payload
  payload=$(cat << EOF
{
  "username": "BBHunt",
  "avatar_url": "https://raw.githubusercontent.com/nicowillis/bbhunt/main/logo.png",
  "embeds": [{
    "description": $(echo "$message" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
    "color": $color
  }]
}
EOF
)
  curl -s -X POST "$DISCORD_WEBHOOK_URL" \
    -H "Content-Type: application/json" \
    -d "$payload" > /dev/null 2>&1 && log_ok "Discord notification sent" || log_warn "Discord notification failed"
}

# ─── Send to Slack ────────────────────────────────────────────────────────────
notify_slack() {
  local message="$1"
  [[ -z "$SLACK_WEBHOOK_URL" ]] && return 0

  curl -s -X POST "$SLACK_WEBHOOK_URL" \
    -H "Content-Type: application/json" \
    -d "{\"text\": $(echo "$message" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')}" \
    > /dev/null 2>&1 && log_ok "Slack notification sent" || log_warn "Slack notification failed"
}

# ─── Unified broadcast ────────────────────────────────────────────────────────
# notify <type> <title> <body> [color_hex_for_discord]
notify() {
  local type="$1"   # "new_subdomain" | "vuln" | "scan_done" | "error"
  local title="$2"
  local body="$3"
  local discord_color="${4:-3447003}"

  local emoji
  case "$type" in
    new_subdomain) emoji="🔎"; discord_color=3066993 ;;
    vuln_critical)  emoji="🚨"; discord_color=15158332 ;;
    vuln_high)      emoji="⚠️"; discord_color=15105570 ;;
    vuln_medium)    emoji="⚡"; discord_color=16776960 ;;
    scan_done)      emoji="✅"; discord_color=3066993 ;;
    error)          emoji="❌"; discord_color=15158332 ;;
    *)              emoji="📌" ;;
  esac

  local full_message="${emoji} *${title}*
${body}
_$(date '+%Y-%m-%d %H:%M:%S')_"

  notify_telegram "$full_message"
  notify_discord  "$full_message" "$discord_color"
  notify_slack    "$full_message"
}

# ─── Batch notify for new subdomains ─────────────────────────────────────────
notify_new_subdomains() {
  local domain="$1"
  local new_file="$2"
  local count
  count=$(count_lines "$new_file")
  [[ $count -eq 0 ]] && return 0

  local body="*Target:* \`${domain}\`
*New subdomains:* ${count}

\`\`\`"
  # Include first 15 in notification, rest in report
  head -15 "$new_file" | while read -r sub; do
    body+="
• ${sub}"
  done
  [[ $count -gt 15 ]] && body+="
... and $((count - 15)) more"
  body+="
\`\`\`"

  notify "new_subdomain" "New Attack Surface — ${domain}" "$body"
}

# ─── Notify for a nuclei finding ─────────────────────────────────────────────
notify_vuln() {
  local severity="$1"
  local template_name="$2"
  local target="$3"
  local extra="${4:-}"

  local sev_lower
  sev_lower=$(echo "$severity" | tr '[:upper:]' '[:lower:]')

  local body="*Template:* \`${template_name}\`
*Target:*   \`${target}\`
*Severity:* ${severity}"
  [[ -n "$extra" ]] && body+="
*Detail:*   ${extra}"

  notify "vuln_${sev_lower}" "Vulnerability Found [${severity}]" "$body"
}
