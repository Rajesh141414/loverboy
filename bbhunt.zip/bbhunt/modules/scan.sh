#!/usr/bin/env bash
# scan.sh — Smart HTTP probing + tiered port scanning

run_scan() {
  local domain="$1"
  local outdir="$2"
  local subdomains_file="${outdir}/subdomains/final.txt"
  local scan_dir="${outdir}/scans"
  mkdir -p "$scan_dir"

  log_section "HTTP Probing & Port Scanning — ${domain}"

  if [[ ! -s "$subdomains_file" ]]; then
    log_warn "No subdomains file found. Run subdomain enum first."
    return 1
  fi

  # ─── 1. HTTP Probing via httpx ────────────────────────────────────────────
  _run_httpx_probe "$subdomains_file" "$scan_dir"

  # ─── 2. Tiered port scanning ─────────────────────────────────────────────
  local alive_hosts="${scan_dir}/alive_ips.txt"
  _extract_ips_from_httpx "${scan_dir}/httpx_full.json" "$alive_hosts"

  if [[ -s "$alive_hosts" ]]; then
    if [[ "$USE_MASSCAN" == "true" ]] && check_tool masscan; then
      _run_masscan "$alive_hosts" "$scan_dir"
    else
      _run_nmap_tiered "$alive_hosts" "$scan_dir"
    fi
  else
    log_warn "No alive IPs extracted for port scanning."
  fi

  log_section "Scan Complete"
  _write_scan_summary "$scan_dir" "$domain"
}

# ─── httpx full probe ─────────────────────────────────────────────────────────
_run_httpx_probe() {
  local infile="$1"
  local scan_dir="$2"

  log_info "Running httpx probe on $(count_lines "$infile") hosts..."

  if ! check_tool httpx; then
    log_error "httpx not found. Cannot proceed with HTTP probing."
    return 1
  fi

  httpx -l "$infile" \
    -threads "$HTTPX_THREADS" \
    -timeout "$HTTPX_TIMEOUT" \
    -rate-limit "$HTTPX_RATE_LIMIT" \
    -follow-redirects \
    -max-redirects 5 \
    -status-code \
    -title \
    -web-server \
    -tech-detect \
    -content-length \
    -location \
    -ip \
    -cname \
    -cdn \
    -json \
    -o "${scan_dir}/httpx_full.json" \
    -silent 2>/dev/null || true

  # Parse JSON into human-readable summary
  if [[ -f "${scan_dir}/httpx_full.json" ]]; then
    python3 - << 'PYEOF'
import json, sys

infile  = sys.argv[1] if len(sys.argv) > 1 else ""
results = []

with open("${scan_dir}/httpx_full.json") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
            results.append(r)
        except:
            continue

# Write filtered alive list
alive_path = "${scan_dir}/alive.txt"
interesting_path = "${scan_dir}/interesting.txt"
boring_codes = {400, 404}
interesting_indicators = ["admin","login","dashboard","portal","api","jenkins","jira",
                           "gitlab","bitbucket","confluence","grafana","kibana","swagger",
                           "phpmyadmin","cpanel","webmail","dev","staging","test","beta",
                           "internal","manage","console","panel","monitor","debug"]

with open(alive_path, "w") as af, open(interesting_path, "w") as inf:
    for r in results:
        code = r.get("status_code", 0)
        if code in boring_codes:
            continue
        url = r.get("url","")
        title = (r.get("title") or "").lower()
        if url:
            af.write(url + "\n")
            # Flag as interesting if title or URL hints at sensitive panel
            if any(kw in url.lower() or kw in title for kw in interesting_indicators):
                inf.write(url + "\n")

print(f"Alive: {len(results)} | Written to {alive_path}")
PYEOF
    # Fallback if python parsing didn't write files
    [[ -f "${scan_dir}/alive.txt" ]] || \
      jq -r '.url // empty' "${scan_dir}/httpx_full.json" 2>/dev/null > "${scan_dir}/alive.txt" || true
  fi

  local alive_count
  alive_count=$(count_lines "${scan_dir}/alive.txt")
  log_ok "HTTP probe complete: ${BOLD}${alive_count}${RESET} alive hosts"

  # Filter out FP titles
  _filter_fp_titles "${scan_dir}/httpx_full.json" "${scan_dir}/fp_filtered.txt"

  # Log interesting findings immediately
  if [[ -s "${scan_dir}/interesting.txt" ]]; then
    log_success "Potentially interesting endpoints:"
    while IFS= read -r url; do
      log_success "  → ${url}"
    done < "${scan_dir}/interesting.txt"
  fi
}

# ─── Filter known FP page titles ──────────────────────────────────────────────
_filter_fp_titles() {
  local json_file="$1"
  local out_clean="$2"

  [[ ! -f "$json_file" ]] && return

  local fp_pattern="$FP_TITLE_PATTERNS"

  python3 - << PYEOF
import json, re

fp_re = re.compile(r"${fp_pattern}", re.IGNORECASE)
min_len = int("${MIN_CONTENT_LENGTH:-200}")

with open("$json_file") as f, open("$out_clean","w") as out:
    for line in f:
        try:
            r = json.loads(line.strip())
        except:
            continue
        title  = r.get("title","") or ""
        cl     = int(r.get("content_length", 0) or 0)
        url    = r.get("url","")
        if not url: continue
        # Skip if title matches FP pattern
        if fp_re.search(title): continue
        # Skip suspiciously short responses
        if cl < min_len and r.get("status_code",0) not in [301,302,307,308]: continue
        out.write(url + "\n")
PYEOF
}

# ─── Extract unique IPs from httpx JSON ──────────────────────────────────────
_extract_ips_from_httpx() {
  local json_file="$1"
  local out_ips="$2"

  [[ ! -f "$json_file" ]] && { touch "$out_ips"; return; }

  jq -r '.host // empty' "$json_file" 2>/dev/null \
    | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' \
    | sort -u > "$out_ips" 2>/dev/null || true

  # Also extract from ip field
  jq -r '.ip // empty' "$json_file" 2>/dev/null \
    | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' \
    >> "$out_ips" 2>/dev/null || true

  sort -u "$out_ips" -o "$out_ips"
  log_info "Unique IPs for port scanning: $(count_lines "$out_ips")"
}

# ─── Tiered Nmap scanning ─────────────────────────────────────────────────────
_run_nmap_tiered() {
  local hosts_file="$1"
  local scan_dir="$2"
  local nmap_dir="${scan_dir}/nmap"
  mkdir -p "$nmap_dir"

  log_info "Starting tiered Nmap scan on $(count_lines "$hosts_file") IPs..."

  if ! check_tool nmap; then
    log_error "nmap not found."
    return 1
  fi

  local interesting_hosts="${nmap_dir}/interesting_hosts.txt"
  : > "$interesting_hosts"

  # Process hosts in batches for parallel scanning
  local i=0
  local pids=()

  while IFS= read -r ip; do
    [[ -z "$ip" ]] && continue

    # Quick scan in background
    (
      local safe_ip
      safe_ip=$(echo "$ip" | tr '.' '_')
      local quick_out="${nmap_dir}/${safe_ip}_quick"

      nmap -T"$NMAP_TIMING" \
        --top-ports 1000 \
        -sV --version-intensity 2 \
        -oA "$quick_out" \
        --open \
        -Pn \
        "$ip" > /dev/null 2>&1 || true

      # Check for interesting ports
      local found_interesting=false
      if grep -qE "(${INTERESTING_PORTS//,/|})/open" "${quick_out}.gnmap" 2>/dev/null; then
        found_interesting=true
      fi

      # Also flag if default creds panels or non-standard services found
      if grep -qiE "jenkins|jira|admin|grafana|kibana|elasticsearch|redis|mongo|mysql|postgres|rdp|vnc|docker" \
        "${quick_out}.nmap" 2>/dev/null; then
        found_interesting=true
      fi

      if [[ "$found_interesting" == "true" ]]; then
        echo "$ip" >> "$interesting_hosts"
        log_success "Interesting ports/services found on: ${ip}"

        # Full port scan on this specific host
        nmap -T"$NMAP_TIMING" \
          -p- \
          -sV --version-intensity 5 \
          -sC \
          -oA "${nmap_dir}/${safe_ip}_full" \
          --open \
          -Pn \
          "$ip" > /dev/null 2>&1 || true

        log_ok "Full scan complete: ${ip}"
      fi
    ) &

    pids+=($!)
    ((i++))

    # Limit parallelism
    if [[ ${#pids[@]} -ge $NMAP_PARALLEL ]]; then
      wait "${pids[@]}"
      pids=()
    fi

  done < "$hosts_file"

  # Wait for remaining
  [[ ${#pids[@]} -gt 0 ]] && wait "${pids[@]}"

  log_ok "Nmap scanning complete."
  _parse_nmap_results "$nmap_dir" "${scan_dir}/nmap_summary.txt"
}

# ─── Masscan fast sweep ───────────────────────────────────────────────────────
_run_masscan() {
  local hosts_file="$1"
  local scan_dir="$2"

  log_info "Running masscan for fast initial sweep (rate: ${MASSCAN_RATE})..."

  local masscan_out="${scan_dir}/masscan_results.json"
  local target_list
  target_list=$(paste -sd',' "$hosts_file")

  masscan "$target_list" \
    -p0-65535 \
    --rate "$MASSCAN_RATE" \
    --open-only \
    -oJ "$masscan_out" 2>/dev/null || true

  # Extract IPs with interesting ports for detailed nmap
  python3 - << PYEOF
import json

interesting = set(map(int, "${INTERESTING_PORTS}".split(",")))
hosts_to_detail = set()

try:
    with open("$masscan_out") as f:
        data = json.load(f)
    for entry in data:
        ip   = entry.get("ip","")
        port = int(entry.get("ports",[{}])[0].get("port",0))
        if port in interesting:
            hosts_to_detail.add(ip)
except Exception as e:
    print(f"masscan parse warning: {e}")

with open("${scan_dir}/masscan_interesting_ips.txt","w") as f:
    f.write("\n".join(sorted(hosts_to_detail)))
print(f"IPs with interesting ports: {len(hosts_to_detail)}")
PYEOF

  # Detailed nmap on interesting IPs found by masscan
  if [[ -s "${scan_dir}/masscan_interesting_ips.txt" ]]; then
    log_info "Detailed Nmap on masscan-flagged IPs..."
    _run_nmap_tiered "${scan_dir}/masscan_interesting_ips.txt" "$scan_dir"
  fi
}

# ─── Parse nmap results into summary ─────────────────────────────────────────
_parse_nmap_results() {
  local nmap_dir="$1"
  local summary_out="$2"

  python3 - << PYEOF
import glob, re, os

results = []
for gnmap_file in glob.glob("$nmap_dir/*.gnmap"):
    ip_match = re.search(r"Host: (\S+)", open(gnmap_file).read())
    if not ip_match:
        continue
    ip = ip_match.group(1)
    port_matches = re.findall(r"(\d+)/open/tcp//([^/]*)/", open(gnmap_file).read())
    for port, service in port_matches:
        results.append(f"{ip}:{port} [{service}]")

with open("$summary_out","w") as f:
    f.write("\n".join(sorted(results)))

print(f"Nmap summary: {len(results)} open ports documented")
PYEOF
}

# ─── Write combined scan summary ─────────────────────────────────────────────
_write_scan_summary() {
  local scan_dir="$1"
  local domain="$2"

  python3 - << PYEOF
import json, glob, os, datetime

summary = {
    "domain": "$domain",
    "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
    "alive_hosts": 0,
    "interesting_hosts": 0,
    "technologies": {},
    "status_code_distribution": {}
}

httpx_json = "$scan_dir/httpx_full.json"
if os.path.exists(httpx_json):
    with open(httpx_json) as f:
        for line in f:
            try:
                r = json.loads(line.strip())
                summary["alive_hosts"] += 1
                code = str(r.get("status_code",""))
                summary["status_code_distribution"][code] = \
                    summary["status_code_distribution"].get(code, 0) + 1
                for tech in (r.get("tech") or []):
                    summary["technologies"][tech] = summary["technologies"].get(tech,0) + 1
            except:
                continue

out = "$scan_dir/scan_summary.json"
with open(out,"w") as f:
    json.dump(summary, f, indent=2)
print(f"Scan summary written: {out}")
PYEOF
}
