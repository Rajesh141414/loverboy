#!/usr/bin/env bash
# subdomain.sh — Multi-source subdomain enumeration with wildcard detection & DNS validation

run_subdomain_enum() {
  local domain="$1"
  local outdir="$2/subdomains"
  mkdir -p "$outdir"

  log_section "Subdomain Enumeration — ${domain}"

  local raw_dir="${outdir}/raw"
  mkdir -p "$raw_dir"

  # ─── 1. Subfinder ─────────────────────────────────────────────────────────
  log_info "Running subfinder..."
  if check_tool subfinder; then
    subfinder -d "$domain" \
      -t "$SUBFINDER_THREADS" \
      -silent \
      -all \
      -o "${raw_dir}/subfinder.txt" 2>/dev/null || true
    log_ok "Subfinder: $(count_lines "${raw_dir}/subfinder.txt") results"
  fi

  # ─── 2. Amass ─────────────────────────────────────────────────────────────
  if [[ "$RUN_AMASS" == "true" ]] && check_tool amass; then
    log_info "Running amass (passive — ${AMASS_TIMEOUT}s timeout)..."
    timeout "$AMASS_TIMEOUT" amass enum \
      -passive \
      -d "$domain" \
      -o "${raw_dir}/amass.txt" 2>/dev/null || true
    log_ok "Amass: $(count_lines "${raw_dir}/amass.txt") results"
  fi

  # ─── 3. Assetfinder ───────────────────────────────────────────────────────
  if [[ "$RUN_ASSETFINDER" == "true" ]] && check_tool assetfinder; then
    log_info "Running assetfinder..."
    assetfinder --subs-only "$domain" > "${raw_dir}/assetfinder.txt" 2>/dev/null || true
    log_ok "Assetfinder: $(count_lines "${raw_dir}/assetfinder.txt") results"
  fi

  # ─── 4. Findomain ─────────────────────────────────────────────────────────
  if [[ "$RUN_FINDOMAIN" == "true" ]] && check_tool findomain; then
    log_info "Running findomain..."
    findomain -t "$domain" -q -u "${raw_dir}/findomain.txt" 2>/dev/null || true
    log_ok "Findomain: $(count_lines "${raw_dir}/findomain.txt") results"
  fi

  # ─── 5. crt.sh certificate transparency ──────────────────────────────────
  log_info "Querying crt.sh..."
  _run_crtsh "$domain" "${raw_dir}/crtsh.txt"
  log_ok "crt.sh: $(count_lines "${raw_dir}/crtsh.txt") results"

  # ─── 6. Combine & corroborate ─────────────────────────────────────────────
  log_info "Combining results..."
  local combined="${outdir}/combined_raw.txt"
  cat "${raw_dir}"/*.txt 2>/dev/null \
    | grep -aE "^[a-zA-Z0-9.*_-]+\\.${domain//./\\.}$" \
    | tr '[:upper:]' '[:lower:]' \
    | sort -u > "$combined"
  log_ok "Combined unique (pre-DNS): $(count_lines "$combined")"

  # Optionally enforce corroboration (seen by N+ tools)
  if [[ "${MIN_TOOL_CORROBORATION}" -gt 1 ]]; then
    log_info "Enforcing corroboration threshold: ${MIN_TOOL_CORROBORATION} tools..."
    _corroborate "${raw_dir}" "$domain" "$MIN_TOOL_CORROBORATION" > "${outdir}/corroborated.txt"
    cp "${outdir}/corroborated.txt" "$combined"
    log_ok "After corroboration: $(count_lines "$combined")"
  fi

  # ─── 7. Wildcard detection ────────────────────────────────────────────────
  log_info "Detecting wildcard DNS..."
  local wildcard_ips="${outdir}/wildcard_ips.txt"
  _detect_wildcards "$domain" "$wildcard_ips"

  # ─── 8. DNS validation via dnsx ───────────────────────────────────────────
  log_info "Validating DNS resolution (dnsx)..."
  local valid="${outdir}/valid.txt"
  local valid_json="${outdir}/valid_dns.json"

  if check_tool dnsx; then
    dnsx -l "$combined" \
      -r "${RESOLVERS_FILE:-}" \
      -threads "$DNSX_THREADS" \
      -a -cname \
      -json \
      -silent \
      -o "$valid_json" 2>/dev/null || true

    # Extract hosts that resolved
    if [[ -f "$valid_json" ]]; then
      jq -r '.host' "$valid_json" 2>/dev/null | sort -u > "$valid"
    else
      # Fallback: use the combined list as-is (dnsx failed)
      cp "$combined" "$valid"
    fi
  else
    # Fallback: basic dig validation
    log_warn "dnsx not found — falling back to dig validation (slower)"
    _validate_with_dig "$combined" "$valid"
  fi

  # ─── 9. Remove wildcard hits ──────────────────────────────────────────────
  if [[ -s "$wildcard_ips" ]]; then
    log_info "Removing wildcard IP matches..."
    _remove_wildcard_hits "$valid" "$wildcard_ips" "$valid_json" "${outdir}/final.txt"
  else
    cp "$valid" "${outdir}/final.txt"
  fi
  dedup_file "${outdir}/final.txt"

  local final_count
  final_count=$(count_lines "${outdir}/final.txt")
  log_success "Final validated subdomains: ${BOLD}${final_count}${RESET}"

  echo "${outdir}/final.txt"
}

# ─── crt.sh query ─────────────────────────────────────────────────────────────
_run_crtsh() {
  local domain="$1"
  local outfile="$2"
  local attempt=0

  while [[ $attempt -lt $CRTSH_RETRIES ]]; do
    local result
    result=$(curl -s --max-time "$CRTSH_TIMEOUT" \
      "https://crt.sh/?q=%25.${domain}&output=json" 2>/dev/null) || true

    if [[ -n "$result" ]]; then
      echo "$result" \
        | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    seen = set()
    for entry in data:
        for name in entry.get('name_value','').split('\n'):
            name = name.strip().lower().lstrip('*.')
            if name and '${domain}' in name and name not in seen:
                seen.add(name)
                print(name)
except: pass
" 2>/dev/null > "$outfile" || true
      return 0
    fi
    ((attempt++))
    sleep 3
  done
  touch "$outfile"   # empty on failure
}

# ─── Corroboration: keep only subdomains found by N+ tools ────────────────────
_corroborate() {
  local raw_dir="$1"
  local domain="$2"
  local threshold="$3"

  # Count how many tool output files each subdomain appears in
  declare -A counts
  for f in "${raw_dir}"/*.txt; do
    [[ -f "$f" ]] || continue
    while IFS= read -r line; do
      [[ -n "$line" ]] && counts["$line"]=$(( ${counts["$line"]:-0} + 1 ))
    done < <(grep -aF ".$domain" "$f" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort -u)
  done

  for sub in "${!counts[@]}"; do
    [[ ${counts[$sub]} -ge $threshold ]] && echo "$sub"
  done | sort -u
}

# ─── Wildcard detection ───────────────────────────────────────────────────────
_detect_wildcards() {
  local domain="$1"
  local outfile="$2"
  : > "$outfile"

  # Query random non-existent subdomains and capture their IPs
  local random_sub
  for i in 1 2 3; do
    random_sub="bbhunt-wild-$(openssl rand -hex 6).${domain}"
    local ip
    ip=$(dig +short "$random_sub" A 2>/dev/null | grep -E '^[0-9]+\.' | head -1) || true
    if [[ -n "$ip" ]]; then
      echo "$ip" >> "$outfile"
      log_warn "Wildcard DNS detected for ${domain} → ${ip}"
    fi
  done
  dedup_file "$outfile"
}

# ─── Remove entries resolving to wildcard IPs ────────────────────────────────
_remove_wildcard_hits() {
  local valid_hosts="$1"
  local wildcard_ips="$2"
  local valid_json="$3"
  local outfile="$4"

  if [[ ! -s "$valid_json" ]]; then
    # No JSON data to cross-reference — just copy
    cp "$valid_hosts" "$outfile"
    return
  fi

  # Build a set of wildcard IPs
  local wild_pattern
  wild_pattern=$(paste -sd'|' "$wildcard_ips" 2>/dev/null) || wild_pattern=""

  if [[ -z "$wild_pattern" ]]; then
    cp "$valid_hosts" "$outfile"
    return
  fi

  # Keep hosts whose resolved IPs don't match any wildcard IP
  jq -r 'select(.a != null) | "\(.host) \(.a[])"' "$valid_json" 2>/dev/null \
    | grep -vE " ($wild_pattern)$" \
    | awk '{print $1}' \
    | sort -u > "$outfile"

  # Add back hosts that didn't have A records in JSON (CNAMEs, etc.)
  jq -r 'select(.a == null) | .host' "$valid_json" 2>/dev/null \
    | sort -u >> "$outfile"

  sort -u "$outfile" -o "$outfile"
}

# ─── Fallback dig validation (if dnsx not available) ─────────────────────────
_validate_with_dig() {
  local infile="$1"
  local outfile="$2"
  : > "$outfile"
  while IFS= read -r sub; do
    [[ -z "$sub" ]] && continue
    if dig +short "$sub" A AAAA 2>/dev/null | grep -qE '[0-9a-f]'; then
      echo "$sub" >> "$outfile"
    fi
    rate_sleep
  done < "$infile"
}
