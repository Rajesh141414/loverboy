#!/usr/bin/env bash
# visual.sh — Screenshots, tech stack detection, and panel identification

run_visual_recon() {
  local domain="$1"
  local outdir="$2"
  local alive_file="${outdir}/scans/alive.txt"
  local shot_dir="${outdir}/screenshots"
  mkdir -p "$shot_dir"

  log_section "Visual Recon — ${domain}"

  if [[ ! -s "$alive_file" ]]; then
    log_warn "No alive hosts. Run scan module first."
    return 1
  fi

  local alive_count
  alive_count=$(count_lines "$alive_file")
  log_info "Screenshotting ${alive_count} alive hosts..."

  # ─── 1. Screenshots via gowitness ─────────────────────────────────────────
  _run_gowitness "$alive_file" "$shot_dir"

  # ─── 2. Tech stack via httpx JSON (already collected) ─────────────────────
  _extract_tech_stack "$outdir"

  # ─── 3. Flag high-value targets ───────────────────────────────────────────
  _identify_high_value_targets "$outdir"

  # ─── 4. Optional: webanalyze deep scan ────────────────────────────────────
  if [[ "$USE_WEBANALYZE" == "true" ]] && check_tool webanalyze; then
    _run_webanalyze "$alive_file" "$shot_dir"
  fi

  log_ok "Visual recon complete. Screenshots: ${shot_dir}"
}

# ─── gowitness screenshot ─────────────────────────────────────────────────────
_run_gowitness() {
  local infile="$1"
  local shot_dir="$2"

  if ! check_tool gowitness; then
    log_warn "gowitness not found — skipping screenshots."
    return
  fi

  local db_path="${shot_dir}/gowitness.sqlite3"
  local screens_path="${shot_dir}/screens"
  mkdir -p "$screens_path"

  gowitness scan file \
    -f "$infile" \
    --db-path "$db_path" \
    --screenshot-path "$screens_path" \
    --screenshot-timeout "$GOWITNESS_TIMEOUT" \
    --threads "$GOWITNESS_THREADS" \
    --screenshot-fullpage \
    --user-agent "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" \
    2>/dev/null || true

  # Generate HTML report from gowitness
  if [[ -f "$db_path" ]]; then
    gowitness report generate \
      --db-path "$db_path" \
      --fullscreen-screenshots \
      --output "${shot_dir}/gowitness_report.html" \
      2>/dev/null || true
    log_ok "Screenshot report: ${shot_dir}/gowitness_report.html"
  fi

  local shot_count
  shot_count=$(find "$screens_path" -name "*.png" 2>/dev/null | wc -l)
  log_ok "Screenshots taken: ${shot_count}"
}

# ─── Extract and summarize tech stacks from httpx JSON ───────────────────────
_extract_tech_stack() {
  local outdir="$1"
  local httpx_json="${outdir}/scans/httpx_full.json"
  local tech_out="${outdir}/screenshots/tech_summary.json"
  local tech_txt="${outdir}/screenshots/tech_summary.txt"

  [[ ! -f "$httpx_json" ]] && return

  python3 - << PYEOF
import json, collections

tech_map  = collections.defaultdict(list)   # tech -> [url, ...]
url_techs = {}                               # url  -> [tech, ...]

with open("$httpx_json") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
        except:
            continue
        url   = r.get("url","")
        techs = r.get("tech") or []
        if not url: continue
        url_techs[url] = techs
        for t in techs:
            tech_map[t].append(url)

# Write JSON
with open("$tech_out","w") as f:
    json.dump({
        "tech_usage":    {k: len(v) for k,v in tech_map.items()},
        "tech_targets":  {k: v[:50] for k,v in tech_map.items()},  # first 50 per tech
        "url_inventory": url_techs
    }, f, indent=2)

# Write human-readable summary
HIGH_VALUE_TECH = {
    "WordPress","Joomla","Drupal","Magento","PrestaShop",  # CMS
    "Jenkins","Gitlab","Bitbucket","Confluence","Jira",    # DevOps
    "Grafana","Kibana","Prometheus","Elasticsearch",        # Monitoring
    "Apache Tomcat","JBoss","WebLogic","WebSphere",        # App Servers
    "Laravel","Django","Rails","Spring Boot",              # Frameworks
    "phpMyAdmin","Adminer",                                # DB panels
    "Swagger UI","GraphQL","Redoc",                        # APIs
    "AWS","Azure","GCP",                                   # Cloud
    "Node.js","PHP","Python","Java",                       # Languages
}

with open("$tech_txt","w") as f:
    f.write("=" * 60 + "\n")
    f.write("TECHNOLOGY STACK SUMMARY\n")
    f.write("=" * 60 + "\n\n")

    f.write("HIGH-VALUE TARGETS BY TECHNOLOGY\n")
    f.write("-" * 40 + "\n")
    for tech in sorted(HIGH_VALUE_TECH):
        if tech in tech_map:
            f.write(f"\n[{tech}] — {len(tech_map[tech])} host(s)\n")
            for url in tech_map[tech][:10]:
                f.write(f"  • {url}\n")

    f.write("\n\nFULL TECHNOLOGY INVENTORY\n")
    f.write("-" * 40 + "\n")
    for tech, urls in sorted(tech_map.items(), key=lambda x: -len(x[1])):
        f.write(f"  {len(urls):>4}  {tech}\n")

print(open("$tech_txt").read())
PYEOF
}

# ─── Identify high-value targets ─────────────────────────────────────────────
_identify_high_value_targets() {
  local outdir="$1"
  local httpx_json="${outdir}/scans/httpx_full.json"
  local hv_out="${outdir}/screenshots/high_value_targets.txt"

  [[ ! -f "$httpx_json" ]] && return

  python3 - << PYEOF
import json, re

# Keywords that strongly indicate interesting targets
PANEL_KEYWORDS = re.compile(
    r"admin|login|dashboard|portal|manage|control|cpanel|"
    r"jenkins|jira|gitlab|confluence|bitbucket|sonarqube|"
    r"grafana|kibana|prometheus|netdata|zabbix|nagios|"
    r"swagger|api-docs|graphql|redoc|openapi|"
    r"staging|dev\b|beta|test|uat|preprod|internal|"
    r"phpmyadmin|adminer|pgadmin|mongo-express|"
    r"webmail|roundcube|squirrelmail|"
    r"jupyter|notebook|zeppelin|"
    r"vault|consul|nomad|"
    r"travis|circleci|teamcity|bamboo|drone",
    re.IGNORECASE
)

STATUS_INTERESTING = {200, 201, 401, 403}  # 401/403 = exists but protected

targets = []
with open("$httpx_json") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
        except:
            continue
        url   = r.get("url","")
        title = (r.get("title","") or "").lower()
        code  = r.get("status_code", 0)
        techs = " ".join(r.get("tech") or []).lower()

        if not url: continue

        score = 0
        reasons = []

        if PANEL_KEYWORDS.search(url):
            score += 3; reasons.append("URL pattern")
        if PANEL_KEYWORDS.search(title):
            score += 3; reasons.append("Title pattern")
        if PANEL_KEYWORDS.search(techs):
            score += 2; reasons.append("Tech stack")
        if code == 401:
            score += 2; reasons.append("Auth required (401)")
        if code == 403:
            score += 1; reasons.append("Forbidden (403)")

        if score >= 2:
            targets.append((score, url, title, code, ", ".join(reasons)))

targets.sort(reverse=True)

with open("$hv_out","w") as f:
    f.write("HIGH-VALUE TARGETS (sorted by interest score)\n")
    f.write("=" * 70 + "\n\n")
    for score, url, title, code, reasons in targets:
        f.write(f"[Score: {score}] [{code}] {url}\n")
        if title: f.write(f"  Title  : {title}\n")
        f.write(f"  Reason : {reasons}\n\n")

print(f"High-value targets identified: {len(targets)}")
if targets:
    print("\nTop 10:")
    for score, url, title, code, reasons in targets[:10]:
        print(f"  [{score}] {url} ({reasons})")
PYEOF
}

# ─── webanalyze deep tech detection ──────────────────────────────────────────
_run_webanalyze() {
  local infile="$1"
  local shot_dir="$2"

  log_info "Running webanalyze for deeper tech fingerprinting..."

  webanalyze -hosts "$infile" \
    -worker 20 \
    -output json \
    > "${shot_dir}/webanalyze.json" 2>/dev/null || true

  log_ok "webanalyze complete: ${shot_dir}/webanalyze.json"
}
