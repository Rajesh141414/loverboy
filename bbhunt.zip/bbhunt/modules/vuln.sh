#!/usr/bin/env bash
# vuln.sh — Nuclei-based vulnerability scanning with FP reduction and re-verification

run_vuln_scan() {
  local domain="$1"
  local outdir="$2"
  local alive_file="${outdir}/scans/alive.txt"
  local vuln_dir="${outdir}/vulns"
  mkdir -p "$vuln_dir"

  log_section "Vulnerability Scanning — ${domain}"

  if [[ ! -s "$alive_file" ]]; then
    log_warn "No alive hosts. Run scan module first."
    return 1
  fi

  if ! check_tool nuclei; then
    log_error "nuclei not found. Skipping vuln scan."
    return 1
  fi

  # Ensure templates are up to date
  _update_nuclei_templates

  # ─── Phase 1: High-confidence targeted scan ────────────────────────────────
  log_info "Phase 1: Targeted scan (exposures, misconfigs, takeovers, default creds)..."
  local phase1_out="${vuln_dir}/phase1_$(date +%Y%m%d_%H%M%S).json"

  nuclei -l "$alive_file" \
    -tags "$NUCLEI_TAGS" \
    -exclude-tags "$NUCLEI_EXCLUDE_TAGS" \
    -severity "$NUCLEI_SEVERITIES" \
    -rate-limit "$NUCLEI_RATE_LIMIT" \
    -threads "$NUCLEI_THREADS" \
    -timeout "$NUCLEI_TIMEOUT" \
    -retries "$NUCLEI_RETRIES" \
    -stats \
    -json \
    -o "$phase1_out" \
    -silent 2>/dev/null || true

  # ─── Phase 2: CVE scan (version-based) ────────────────────────────────────
  log_info "Phase 2: CVE scan..."
  local phase2_out="${vuln_dir}/phase2_cve_$(date +%Y%m%d_%H%M%S).json"

  nuclei -l "$alive_file" \
    -tags "cve" \
    -exclude-tags "$NUCLEI_EXCLUDE_TAGS,dos,fuzzing" \
    -severity "critical,high" \
    -rate-limit "$NUCLEI_RATE_LIMIT" \
    -threads "$NUCLEI_THREADS" \
    -timeout "$NUCLEI_TIMEOUT" \
    -retries "$NUCLEI_RETRIES" \
    -json \
    -o "$phase2_out" \
    -silent 2>/dev/null || true

  # ─── Phase 3: Custom templates (if configured) ────────────────────────────
  if [[ -n "$CUSTOM_TEMPLATES_DIR" && -d "$CUSTOM_TEMPLATES_DIR" ]]; then
    log_info "Phase 3: Custom templates from ${CUSTOM_TEMPLATES_DIR}..."
    local phase3_out="${vuln_dir}/phase3_custom_$(date +%Y%m%d_%H%M%S).json"
    nuclei -l "$alive_file" \
      -t "$CUSTOM_TEMPLATES_DIR" \
      -rate-limit "$NUCLEI_RATE_LIMIT" \
      -threads "$NUCLEI_THREADS" \
      -timeout "$NUCLEI_TIMEOUT" \
      -retries "$NUCLEI_RETRIES" \
      -json \
      -o "$phase3_out" \
      -silent 2>/dev/null || true
  fi

  # ─── Merge all findings ───────────────────────────────────────────────────
  local all_findings="${vuln_dir}/all_findings_raw.json"
  cat "${vuln_dir}"/phase*.json 2>/dev/null > "$all_findings"

  # ─── FP reduction ─────────────────────────────────────────────────────────
  log_info "Applying false positive filters..."
  local filtered_findings="${vuln_dir}/all_findings_filtered.json"
  _filter_nuclei_fps "$all_findings" "$filtered_findings"

  # ─── Re-verification of critical/high ─────────────────────────────────────
  if [[ "$NUCLEI_VERIFY" == "true" ]]; then
    log_info "Re-verifying critical and high severity findings..."
    local verified_out="${vuln_dir}/verified_findings.json"
    _verify_critical_findings "$filtered_findings" "$verified_out"
  else
    cp "$filtered_findings" "${vuln_dir}/verified_findings.json"
  fi

  # ─── Parse, report, and notify ────────────────────────────────────────────
  _process_final_findings "${vuln_dir}/verified_findings.json" "$domain" "$vuln_dir"
}

# ─── Update nuclei templates ──────────────────────────────────────────────────
_update_nuclei_templates() {
  local templates_dir="${HOME}/nuclei-templates"
  if [[ ! -d "$templates_dir" ]]; then
    log_info "Nuclei templates not found. Running nuclei to auto-download..."
    nuclei -update-templates -silent 2>/dev/null || true
  else
    local age_hours
    age_hours=$(file_age_hours "${templates_dir}/.git/FETCH_HEAD" 2>/dev/null || echo 999)
    if [[ $age_hours -gt 24 ]]; then
      log_info "Updating nuclei templates (last update: ${age_hours}h ago)..."
      nuclei -update-templates -silent 2>/dev/null || true
    else
      log_info "Nuclei templates are fresh (${age_hours}h old). Skipping update."
    fi
  fi
}

# ─── Remove known false positives from nuclei output ─────────────────────────
_filter_nuclei_fps() {
  local infile="$1"
  local outfile="$2"

  [[ ! -s "$infile" ]] && { touch "$outfile"; return; }

  python3 - << 'PYEOF'
import json, sys, re

# Templates known to produce high FP rates — skip these
FP_TEMPLATES = {
    "generic-tokens-in-js",
    "email-extractor",
    "phone-numbers",
    "ip-address-disclosure",
    "aws-bucket-service",   # often harmless
    "http-missing-security-headers",  # informational, not bugs
    "ssl-certificate-expiry",
    "deprecated-tls",
    "nameserver-fingerprint",
}

# Patterns in matched data that are likely FPs
FP_MATCHED_PATTERNS = [
    r"^(localhost|127\.0\.0\.1|0\.0\.0\.0)",
    r"example\.com",
    r"test@test\.com",
    r"^AAAA",                      # common placeholder
    r"<html>.*</html>",            # full page dumps
]
fp_re = [re.compile(p, re.IGNORECASE) for p in FP_MATCHED_PATTERNS]

infile  = sys.argv[1] if len(sys.argv) > 1 else ""
outfile = sys.argv[2] if len(sys.argv) > 2 else ""

kept = []
skipped = 0

with open("${infile}") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
        except:
            continue

        template_id = r.get("template-id","")
        if template_id in FP_TEMPLATES:
            skipped += 1
            continue

        matched = str(r.get("matched-at","")) + str(r.get("extracted-results",""))
        if any(rx.search(matched) for rx in fp_re):
            skipped += 1
            continue

        kept.append(r)

with open("${outfile}","w") as f:
    for r in kept:
        f.write(json.dumps(r) + "\n")

print(f"FP filter: kept {len(kept)}, removed {skipped}")
PYEOF
}

# ─── Re-verify critical/high by re-sending the exact request ──────────────────
_verify_critical_findings() {
  local infile="$1"
  local outfile="$2"

  [[ ! -s "$infile" ]] && { touch "$outfile"; return; }

  local to_verify="${outfile%.json}_to_verify.txt"
  local verified_count=0
  local failed_count=0

  # Extract URLs of critical/high findings
  jq -r 'select(.info.severity == "critical" or .info.severity == "high") | .matched-at' \
    "$infile" 2>/dev/null | sort -u > "$to_verify"

  if [[ ! -s "$to_verify" ]]; then
    cp "$infile" "$outfile"
    return
  fi

  log_info "Re-verifying $(count_lines "$to_verify") critical/high targets..."

  local verify_results="${outfile%.json}_verify_pass.json"

  # Run nuclei again with more retries and no rate limit bypass
  nuclei -l "$to_verify" \
    -severity "critical,high" \
    -rate-limit 30 \
    -retries "$NUCLEI_VERIFY_RETRIES" \
    -timeout 15 \
    -json \
    -o "$verify_results" \
    -silent 2>/dev/null || true

  if [[ -s "$verify_results" ]]; then
    # Build set of verified (template+target) pairs
    python3 - << PYEOF
import json

# Load second-pass verified findings
verified_pairs = set()
try:
    with open("$verify_results") as f:
        for line in f:
            try:
                r = json.loads(line.strip())
                key = r.get("template-id","") + "|" + r.get("matched-at","")
                verified_pairs.add(key)
            except:
                pass
except: pass

# From original, keep: (a) all medium/low/info, (b) critical/high only if verified
kept = []
with open("$infile") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
        except:
            continue
        sev = r.get("info",{}).get("severity","").lower()
        if sev in ("critical","high"):
            key = r.get("template-id","") + "|" + r.get("matched-at","")
            if key in verified_pairs:
                kept.append(r)
        else:
            kept.append(r)

with open("$outfile","w") as f:
    for r in kept:
        f.write(json.dumps(r) + "\n")

print(f"Verification: {len(kept)} findings confirmed")
PYEOF
  else
    # Nothing re-verified — keep only medium and below to be safe
    jq -c 'select(.info.severity == "medium" or .info.severity == "low" or .info.severity == "info")' \
      "$infile" > "$outfile" 2>/dev/null || cp "$infile" "$outfile"
    log_warn "Re-verification pass returned no results — keeping medium/low only from this batch"
  fi
}

# ─── Process verified findings: log + notify ──────────────────────────────────
_process_final_findings() {
  local findings_file="$1"
  local domain="$2"
  local vuln_dir="$3"

  [[ ! -s "$findings_file" ]] && {
    log_info "No verified vulnerabilities found."
    return
  }

  # Human-readable summary
  local summary_txt="${vuln_dir}/findings_summary.txt"

  python3 - << PYEOF
import json, sys

by_severity = {"critical":[], "high":[], "medium":[], "low":[], "info":[]}

with open("$findings_file") as f:
    for line in f:
        try:
            r = json.loads(line.strip())
            sev = r.get("info",{}).get("severity","info").lower()
            entry = {
                "template": r.get("template-id",""),
                "name": r.get("info",{}).get("name",""),
                "url": r.get("matched-at",""),
                "severity": sev,
                "tags": r.get("info",{}).get("tags",""),
                "description": r.get("info",{}).get("description","")[:120],
            }
            if sev in by_severity:
                by_severity[sev].append(entry)
        except:
            continue

SEV_ICONS = {"critical":"🚨","high":"⚠️","medium":"⚡","low":"ℹ️","info":"📝"}

with open("$summary_txt","w") as f:
    f.write("=" * 70 + "\n")
    f.write(f"VULNERABILITY FINDINGS — ${domain}\n")
    f.write("=" * 70 + "\n\n")
    total = 0
    for sev in ["critical","high","medium","low","info"]:
        items = by_severity[sev]
        if not items: continue
        f.write(f"{SEV_ICONS[sev]} {sev.upper()} ({len(items)})\n")
        f.write("-" * 40 + "\n")
        for item in items:
            f.write(f"  Template : {item['template']}\n")
            f.write(f"  Name     : {item['name']}\n")
            f.write(f"  URL      : {item['url']}\n")
            if item['description']:
                f.write(f"  Desc     : {item['description']}\n")
            f.write("\n")
            total += 1
    f.write(f"\nTotal: {total} findings\n")

print(open("$summary_txt").read())
PYEOF

  # Send notifications only for critical/high — everything else in the report
  while IFS= read -r line; do
    local sev template target
    sev=$(echo "$line" | python3 -c "import json,sys; r=json.loads(sys.stdin.read()); print(r.get('info',{}).get('severity',''))" 2>/dev/null)
    template=$(echo "$line" | python3 -c "import json,sys; r=json.loads(sys.stdin.read()); print(r.get('template-id',''))" 2>/dev/null)
    target=$(echo "$line" | python3 -c "import json,sys; r=json.loads(sys.stdin.read()); print(r.get('matched-at',''))" 2>/dev/null)

    case "$sev" in
      critical|high) notify_vuln "$sev" "$template" "$target" ;;
    esac
  done < <(jq -c 'select(.info.severity == "critical" or .info.severity == "high")' \
    "$findings_file" 2>/dev/null)
}
