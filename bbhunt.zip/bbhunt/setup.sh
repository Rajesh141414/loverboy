#!/usr/bin/env bash
# setup.sh — Install all BBHunt dependencies automatically
# Supports: Ubuntu/Debian, Kali Linux, macOS (Homebrew)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/utils/helpers.sh"

GO_VERSION="1.21.5"
TOOLS_DIR="${HOME}/.bbhunt/bin"
mkdir -p "$TOOLS_DIR"

print_banner
log_section "BBHunt Setup"

# ─── Detect OS ────────────────────────────────────────────────────────────────
detect_os() {
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "macos"
  elif [[ -f /etc/debian_version ]]; then
    echo "debian"
  elif [[ -f /etc/redhat-release ]]; then
    echo "redhat"
  else
    echo "unknown"
  fi
}
OS=$(detect_os)
log_info "Detected OS: ${OS}"

# ─── Package manager install ─────────────────────────────────────────────────
install_system_packages() {
  log_info "Installing system dependencies..."
  case "$OS" in
    debian)
      sudo apt-get update -qq
      sudo apt-get install -y -qq \
        curl wget git nmap masscan python3 python3-pip \
        jq dnsutils openssl unzip build-essential
      ;;
    macos)
      if ! command -v brew &>/dev/null; then
        log_error "Homebrew not found. Install from https://brew.sh"
        exit 1
      fi
      brew install curl wget git nmap jq openssl python3 2>/dev/null || true
      ;;
    *)
      log_warn "Unknown OS. Please manually install: curl wget git nmap python3 jq openssl"
      ;;
  esac
}

# ─── Go installation ─────────────────────────────────────────────────────────
install_go() {
  if command -v go &>/dev/null; then
    local current_ver
    current_ver=$(go version | awk '{print $3}' | tr -d 'go')
    log_ok "Go already installed: ${current_ver}"
    return
  fi

  log_info "Installing Go ${GO_VERSION}..."
  local arch
  arch=$(uname -m | sed 's/x86_64/amd64/;s/aarch64/arm64/')
  local goos
  [[ "$OS" == "macos" ]] && goos="darwin" || goos="linux"

  local go_tar="go${GO_VERSION}.${goos}-${arch}.tar.gz"
  wget -q "https://go.dev/dl/${go_tar}" -O /tmp/${go_tar}
  sudo rm -rf /usr/local/go
  sudo tar -C /usr/local -xzf /tmp/${go_tar}
  rm /tmp/${go_tar}

  export PATH="$PATH:/usr/local/go/bin"
  echo 'export PATH="$PATH:/usr/local/go/bin"' >> ~/.bashrc
  echo 'export PATH="$PATH:$(go env GOPATH)/bin"' >> ~/.bashrc
  export PATH="$PATH:$(go env GOPATH)/bin"

  log_ok "Go ${GO_VERSION} installed"
}

# ─── Go tools ─────────────────────────────────────────────────────────────────
install_go_tool() {
  local name="$1"
  local pkg="$2"
  if command -v "$name" &>/dev/null; then
    log_ok "${name} already installed"
    return
  fi
  log_info "Installing ${name}..."
  GOBIN="${TOOLS_DIR}" go install "${pkg}@latest" 2>/dev/null && \
    log_ok "${name} installed" || \
    log_warn "${name} install failed — try manually: go install ${pkg}@latest"
}

# ─── Python packages ──────────────────────────────────────────────────────────
install_python_packages() {
  log_info "Installing Python packages..."
  pip3 install --quiet --user requests 2>/dev/null || true
}

# ─── nuclei templates ─────────────────────────────────────────────────────────
setup_nuclei_templates() {
  if [[ ! -d "${HOME}/nuclei-templates" ]]; then
    log_info "Downloading nuclei templates..."
    nuclei -update-templates -silent 2>/dev/null || true
  else
    log_ok "nuclei templates already present"
  fi
}

# ─── Public resolvers for dnsx ───────────────────────────────────────────────
setup_resolvers() {
  local resolvers_file="${HOME}/.bbhunt/resolvers.txt"
  if [[ ! -f "$resolvers_file" ]]; then
    log_info "Downloading public DNS resolvers..."
    cat > "$resolvers_file" << 'RESOLVERS'
1.1.1.1
8.8.8.8
8.8.4.4
9.9.9.9
208.67.222.222
208.67.220.220
1.0.0.1
64.6.64.6
64.6.65.6
77.88.8.8
RESOLVERS
    log_ok "Resolvers written to ${resolvers_file}"
  fi
}

# ─── PATH config ─────────────────────────────────────────────────────────────
setup_path() {
  local profile_file="${HOME}/.bashrc"
  [[ "$OS" == "macos" ]] && profile_file="${HOME}/.zshrc"

  if ! grep -q "bbhunt" "$profile_file" 2>/dev/null; then
    echo "" >> "$profile_file"
    echo "# BBHunt tools" >> "$profile_file"
    echo "export PATH=\"\$PATH:${TOOLS_DIR}:\$(go env GOPATH)/bin\"" >> "$profile_file"
    log_ok "PATH updated in ${profile_file}"
  fi
  export PATH="$PATH:${TOOLS_DIR}"
}

# ─── Main install flow ────────────────────────────────────────────────────────
main() {
  log_section "Step 1/5: System packages"
  install_system_packages

  log_section "Step 2/5: Go language"
  install_go

  log_section "Step 3/5: Go-based security tools"
  export PATH="$PATH:/usr/local/go/bin"
  export PATH="$PATH:$(go env GOPATH 2>/dev/null)/bin"

  install_go_tool "subfinder"   "github.com/projectdiscovery/subfinder/v2/cmd/subfinder"
  install_go_tool "httpx"       "github.com/projectdiscovery/httpx/cmd/httpx"
  install_go_tool "dnsx"        "github.com/projectdiscovery/dnsx/cmd/dnsx"
  install_go_tool "nuclei"      "github.com/projectdiscovery/nuclei/v3/cmd/nuclei"
  install_go_tool "anew"        "github.com/tomnomnom/anew"
  install_go_tool "assetfinder" "github.com/tomnomnom/assetfinder"
  install_go_tool "gowitness"   "github.com/sensepost/gowitness"
  install_go_tool "findomain"   "github.com/findomain/findomain"
  install_go_tool "amass"       "github.com/owasp-amass/amass/v4/..."
  install_go_tool "webanalyze"  "github.com/rverton/webanalyze/cmd/webanalyze"

  log_section "Step 4/5: Python packages"
  install_python_packages

  log_section "Step 5/5: Configuration"
  setup_nuclei_templates
  setup_resolvers
  setup_path
  chmod +x "${SCRIPT_DIR}/bbhunt.sh"

  log_section "Setup Complete!"
  echo ""
  echo -e "  ${BOLD}Next steps:${RESET}"
  echo -e "  1. Edit ${CYAN}config/config.sh${RESET} — add your Telegram/Discord tokens"
  echo -e "  2. Run: ${CYAN}./bbhunt.sh -d yourtarget.com${RESET}"
  echo -e "  3. For monitoring: add to crontab with ${CYAN}./bbhunt.sh --monitor${RESET}"
  echo ""
  echo -e "  ${YELLOW}Note:${RESET} API keys for subfinder greatly improve subdomain discovery."
  echo -e "  Add them at: ${CYAN}~/.config/subfinder/provider-config.yaml${RESET}"
  echo ""

  # ─── Optional API key setup guide ────────────────────────────────────────
  if [[ ! -f "${HOME}/.config/subfinder/provider-config.yaml" ]]; then
    mkdir -p "${HOME}/.config/subfinder"
    cat > "${HOME}/.config/subfinder/provider-config.yaml" << 'YAML'
# Add free API keys here to massively improve subdomain discovery
# Get keys from the respective services (all have free tiers)
securitytrails: []
# - YOUR_SECURITYTRAILS_KEY
censys:
  - YOUR_CENSYS_ID:YOUR_CENSYS_SECRET
shodan: []
# - YOUR_SHODAN_KEY
virustotal: []
# - YOUR_VIRUSTOTAL_KEY
binaryedge: []
# - YOUR_BINARYEDGE_KEY
YAML
    log_info "Created subfinder API config template: ~/.config/subfinder/provider-config.yaml"
  fi
}

main "$@"
