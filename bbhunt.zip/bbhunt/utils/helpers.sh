#!/usr/bin/env bash
# helpers.sh — Logging, colors, common utilities

# ─── Colors ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; MAGENTA='\033[0;35m'
BOLD='\033[1m'; DIM='\033[2m'; RESET='\033[0m'

# ─── Logging ──────────────────────────────────────────────────────────────────
log_info()    { echo -e "${BLUE}[INFO]${RESET}  $(ts) $*"; }
log_ok()      { echo -e "${GREEN}[OK]${RESET}    $(ts) $*"; }
log_warn()    { echo -e "${YELLOW}[WARN]${RESET}  $(ts) $*"; }
log_error()   { echo -e "${RED}[ERROR]${RESET} $(ts) $*" >&2; }
log_success() { echo -e "${GREEN}${BOLD}[FOUND]${RESET} $(ts) $*"; }
log_section() { echo -e "\n${CYAN}${BOLD}━━━ $* ━━━${RESET}\n"; }
log_debug()   { [[ "${DEBUG:-0}" == "1" ]] && echo -e "${DIM}[DEBUG] $(ts) $*${RESET}"; }
ts()          { date '+%H:%M:%S'; }

# ─── Banner ───────────────────────────────────────────────────────────────────
print_banner() {
  echo -e "${CYAN}${BOLD}"
  cat << 'EOF'
  ██████╗ ██████╗ ██╗  ██╗██╗   ██╗███╗   ██╗████████╗
  ██╔══██╗██╔══██╗██║  ██║██║   ██║████╗  ██║╚══██╔══╝
  ██████╔╝██████╔╝███████║██║   ██║██╔██╗ ██║   ██║
  ██╔══██╗██╔══██╗██╔══██║██║   ██║██║╚██╗██║   ██║
  ██████╔╝██████╔╝██║  ██║╚██████╔╝██║ ╚████║   ██║
  ╚═════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝   ╚═╝
      Automated Bug Bounty Recon — Professional Edition
EOF
  echo -e "${RESET}"
}

# ─── Tool checks ─────────────────────────────────────────────────────────────
check_tool() {
  local tool="$1"
  if ! command -v "$tool" &>/dev/null; then
    log_warn "Tool not found: ${BOLD}$tool${RESET}. Run ${CYAN}./setup.sh${RESET} to install."
    return 1
  fi
  return 0
}

check_required_tools() {
  local missing=0
  local required=("subfinder" "httpx" "nmap" "nuclei" "anew" "dnsx")
  local optional=("amass" "assetfinder" "findomain" "gowitness" "masscan" "webanalyze")

  log_section "Tool availability check"
  for t in "${required[@]}"; do
    if command -v "$t" &>/dev/null; then
      log_ok "  [required] $t"
    else
      log_error "  [MISSING]  $t (required)"
      ((missing++))
    fi
  done
  for t in "${optional[@]}"; do
    if command -v "$t" &>/dev/null; then
      log_ok "  [optional] $t"
    else
      log_warn "  [missing]  $t (optional — skipping when absent)"
    fi
  done

  if [[ $missing -gt 0 ]]; then
    log_error "$missing required tool(s) missing. Run ./setup.sh first."
    return 1
  fi
}

# ─── Directory helpers ────────────────────────────────────────────────────────
make_output_dirs() {
  local base="$1"
  mkdir -p "$base"/{subdomains,scans,vulns,screenshots,reports,logs,diffs}
  log_ok "Output directories created at: $base"
}

# ─── Misc ─────────────────────────────────────────────────────────────────────
count_lines() { [[ -f "$1" ]] && wc -l < "$1" || echo 0; }
file_age_hours() {
  local f="$1"
  [[ -f "$f" ]] || { echo 9999; return; }
  echo $(( ( $(date +%s) - $(date -r "$f" +%s) ) / 3600 ))
}

# Sanitize domain to safe filename
safe_name() { echo "$1" | tr '/:' '__' | tr -dc '[:alnum:]_.-'; }

# Rate-limit helper: sleep between requests
rate_sleep() { sleep "${RATE_SLEEP:-0.5}"; }

# Deduplicate + sort a file in-place
dedup_file() { sort -u "$1" -o "$1"; }

# Check if a domain looks like a wildcard hit
is_wildcard_ip() {
  local ip="$1"
  local wild_ips_file="$2"
  [[ -f "$wild_ips_file" ]] && grep -qF "$ip" "$wild_ips_file"
}

# Extract root domain (handles subdomains)
root_domain() {
  echo "$1" | awk -F'.' '{
    n=NF
    if (n>=3 && length($(n-1))<=3) print $(n-2)"."$(n-1)"."$n
    else print $(n-1)"."$n
  }'
}
