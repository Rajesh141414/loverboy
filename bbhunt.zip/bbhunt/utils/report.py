#!/usr/bin/env python3
"""
report.py — Generate a professional, dark-themed HTML security report
Usage: python3 report.py <outdir> <domain>
"""

import json
import os
import sys
import glob
import datetime
from pathlib import Path

OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "."
DOMAIN = sys.argv[2] if len(sys.argv) > 2 else "unknown"
REPORT_TITLE = os.environ.get("REPORT_TITLE", "BBHunt Recon Report")


def read_json_lines(path):
    results = []
    try:
        with open(path) as f:
            for line in f:
                try:
                    results.append(json.loads(line.strip()))
                except:
                    pass
    except:
        pass
    return results


def read_lines(path):
    try:
        with open(path) as f:
            return [l.strip() for l in f if l.strip()]
    except:
        return []


def read_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return {}


def count_file(path):
    return len(read_lines(path))


# ─── Data loading ─────────────────────────────────────────────────────────────
subdomains    = read_lines(f"{OUTDIR}/subdomains/final.txt")
new_ever      = read_lines(f"{OUTDIR}/subdomains/all_new_ever.txt")
alive_hosts   = read_lines(f"{OUTDIR}/scans/alive.txt")
interesting   = read_lines(f"{OUTDIR}/scans/interesting.txt")
hv_targets    = read_lines(f"{OUTDIR}/screenshots/high_value_targets.txt")
nmap_summary  = read_lines(f"{OUTDIR}/scans/nmap_summary.txt")
scan_summary  = read_json(f"{OUTDIR}/scans/scan_summary.json")
diff_data     = read_json(f"{OUTDIR}/diffs/latest_diff.json")

# Load findings
findings_file = f"{OUTDIR}/vulns/verified_findings.json"
findings      = read_json_lines(findings_file)
by_sev = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
for f in findings:
    sev = f.get("info", {}).get("severity", "info").lower()
    if sev in by_sev:
        by_sev[sev].append(f)

# Tech
tech_data = read_json(f"{OUTDIR}/screenshots/tech_summary.json")
tech_usage = tech_data.get("tech_usage", {})
top_techs = sorted(tech_usage.items(), key=lambda x: -x[1])[:20]

# Stats
ts_str = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

SEV_COLORS = {
    "critical": "#ff4444",
    "high":     "#ff8800",
    "medium":   "#ffcc00",
    "low":      "#44aaff",
    "info":     "#aaaaaa",
}
SEV_ICONS = {
    "critical": "🚨",
    "high":     "⚠️",
    "medium":   "⚡",
    "low":      "ℹ️",
    "info":     "📝",
}


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def finding_card(f):
    sev   = f.get("info", {}).get("severity", "info").lower()
    name  = esc(f.get("info", {}).get("name", ""))
    tmpl  = esc(f.get("template-id", ""))
    url   = esc(f.get("matched-at", ""))
    desc  = esc((f.get("info", {}).get("description") or "")[:200])
    tags  = esc(", ".join(f.get("info", {}).get("tags", []) or []))
    color = SEV_COLORS.get(sev, "#aaa")
    icon  = SEV_ICONS.get(sev, "📌")
    return f"""
<div class="finding-card" style="border-left: 3px solid {color};">
  <div class="finding-header">
    <span class="sev-badge" style="background:{color}22;color:{color};border:1px solid {color}44">{icon} {sev.upper()}</span>
    <span class="finding-name">{name}</span>
    <code class="tmpl-id">{tmpl}</code>
  </div>
  <div class="finding-url"><a href="{url}" target="_blank" rel="noopener">{url}</a></div>
  {f'<div class="finding-desc">{desc}</div>' if desc else ''}
  {f'<div class="finding-tags">{tags}</div>' if tags else ''}
</div>"""


def tech_badge(tech, count):
    return f'<span class="tech-badge">{esc(tech)} <b>{count}</b></span>'


def subdomain_rows(subs, limit=200):
    rows = ""
    for s in subs[:limit]:
        rows += f"<tr><td><code>{esc(s)}</code></td></tr>\n"
    if len(subs) > limit:
        rows += f"<tr><td class='muted'>... and {len(subs)-limit} more</td></tr>\n"
    return rows


def nmap_rows():
    rows = ""
    for line in nmap_summary[:100]:
        parts = line.split(" ", 1)
        ip_port = esc(parts[0]) if parts else ""
        service = esc(parts[1]) if len(parts) > 1 else ""
        rows += f"<tr><td><code>{ip_port}</code></td><td>{service}</td></tr>\n"
    return rows


html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(REPORT_TITLE)} — {esc(DOMAIN)}</title>
<style>
  :root {{
    --bg:       #0d1117;
    --bg2:      #161b22;
    --bg3:      #21262d;
    --border:   #30363d;
    --text:     #e6edf3;
    --muted:    #8b949e;
    --accent:   #58a6ff;
    --green:    #3fb950;
    --red:      #ff4444;
    --orange:   #ff8800;
    --yellow:   #ffcc00;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; font-size: 14px; line-height: 1.6; }}
  a {{ color: var(--accent); text-decoration: none; }}
  a:hover {{ text-decoration: underline; }}
  code {{ background: var(--bg3); padding: 2px 6px; border-radius: 4px; font-family: "SF Mono", "Fira Code", monospace; font-size: 12px; }}

  .header {{ background: var(--bg2); border-bottom: 1px solid var(--border); padding: 24px 40px; }}
  .header h1 {{ font-size: 22px; font-weight: 600; }}
  .header .meta {{ color: var(--muted); font-size: 13px; margin-top: 6px; }}
  .header .domain {{ color: var(--accent); font-weight: 600; }}

  .container {{ max-width: 1200px; margin: 0 auto; padding: 32px 40px; }}

  .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 32px; }}
  .stat-card {{ background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 20px; text-align: center; }}
  .stat-card .value {{ font-size: 32px; font-weight: 700; line-height: 1; margin-bottom: 6px; }}
  .stat-card .label {{ color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .5px; }}
  .stat-card.critical .value {{ color: var(--red); }}
  .stat-card.high .value {{ color: var(--orange); }}
  .stat-card.medium .value {{ color: var(--yellow); }}
  .stat-card.domains .value {{ color: var(--accent); }}
  .stat-card.alive .value {{ color: var(--green); }}

  .section {{ margin-bottom: 40px; }}
  .section h2 {{ font-size: 18px; font-weight: 600; border-bottom: 1px solid var(--border); padding-bottom: 12px; margin-bottom: 20px; }}

  .finding-card {{ background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; padding: 16px; margin-bottom: 12px; }}
  .finding-header {{ display: flex; align-items: center; gap: 12px; margin-bottom: 8px; flex-wrap: wrap; }}
  .sev-badge {{ font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 4px; white-space: nowrap; }}
  .finding-name {{ font-weight: 600; font-size: 15px; }}
  .tmpl-id {{ font-size: 11px; color: var(--muted); }}
  .finding-url {{ color: var(--accent); margin-bottom: 4px; word-break: break-all; font-size: 13px; }}
  .finding-desc {{ color: var(--muted); font-size: 13px; margin-top: 6px; }}
  .finding-tags {{ font-size: 11px; color: var(--muted); margin-top: 6px; }}

  table {{ width: 100%; border-collapse: collapse; background: var(--bg2); border-radius: 8px; overflow: hidden; }}
  th {{ background: var(--bg3); padding: 10px 14px; text-align: left; font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); border-bottom: 1px solid var(--border); }}
  td {{ padding: 8px 14px; border-bottom: 1px solid var(--border); vertical-align: middle; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover td {{ background: var(--bg3); }}
  .muted {{ color: var(--muted); font-style: italic; }}

  .tech-grid {{ display: flex; flex-wrap: wrap; gap: 8px; }}
  .tech-badge {{ background: var(--bg3); border: 1px solid var(--border); border-radius: 20px; padding: 4px 12px; font-size: 12px; }}
  .tech-badge b {{ color: var(--accent); margin-left: 4px; }}

  .new-badge {{ background: #1a3a1a; color: var(--green); border: 1px solid #3fb95044; font-size: 11px; padding: 2px 8px; border-radius: 4px; }}
  .no-findings {{ color: var(--muted); padding: 20px; text-align: center; background: var(--bg2); border-radius: 8px; border: 1px dashed var(--border); }}
  .tab-nav {{ display: flex; gap: 0; border-bottom: 1px solid var(--border); margin-bottom: 20px; }}
  .tab-btn {{ background: none; border: none; color: var(--muted); padding: 10px 20px; cursor: pointer; font-size: 14px; border-bottom: 2px solid transparent; }}
  .tab-btn.active {{ color: var(--text); border-bottom-color: var(--accent); }}
  .tab-pane {{ display: none; }}
  .tab-pane.active {{ display: block; }}
</style>
</head>
<body>

<div class="header">
  <h1>🔍 {esc(REPORT_TITLE)}</h1>
  <div class="meta">
    Target: <span class="domain">{esc(DOMAIN)}</span> &nbsp;·&nbsp;
    Generated: {ts_str} &nbsp;·&nbsp;
    BBHunt Automated Recon
  </div>
</div>

<div class="container">

<!-- Stats cards -->
<div class="stats-grid">
  <div class="stat-card domains">
    <div class="value">{len(subdomains)}</div>
    <div class="label">Subdomains</div>
  </div>
  <div class="stat-card alive">
    <div class="value">{len(alive_hosts)}</div>
    <div class="label">Alive Hosts</div>
  </div>
  <div class="stat-card critical">
    <div class="value">{len(by_sev['critical'])}</div>
    <div class="label">Critical</div>
  </div>
  <div class="stat-card high">
    <div class="value">{len(by_sev['high'])}</div>
    <div class="label">High</div>
  </div>
  <div class="stat-card medium">
    <div class="value">{len(by_sev['medium'])}</div>
    <div class="label">Medium</div>
  </div>
  <div class="stat-card">
    <div class="value" style="color:var(--green)">{len(new_ever)}</div>
    <div class="label">New (Ever)</div>
  </div>
</div>

<!-- Tabs -->
<div class="tab-nav">
  <button class="tab-btn active" onclick="showTab('findings')">Findings</button>
  <button class="tab-btn" onclick="showTab('subdomains')">Subdomains</button>
  <button class="tab-btn" onclick="showTab('targets')">High-Value</button>
  <button class="tab-btn" onclick="showTab('ports')">Open Ports</button>
  <button class="tab-btn" onclick="showTab('tech')">Tech Stack</button>
  <button class="tab-btn" onclick="showTab('newassets')">New Assets</button>
</div>

<!-- FINDINGS TAB -->
<div id="tab-findings" class="tab-pane active">
  <div class="section">
    <h2>🚨 Vulnerability Findings ({len(findings)} total)</h2>
    {''.join(finding_card(f) for sev in ['critical','high','medium','low','info'] for f in by_sev[sev])
      if findings else '<div class="no-findings">No verified vulnerabilities found.</div>'}
  </div>
</div>

<!-- SUBDOMAINS TAB -->
<div id="tab-subdomains" class="tab-pane">
  <div class="section">
    <h2>🌐 Discovered Subdomains ({len(subdomains)})</h2>
    <table>
      <tr><th>Subdomain</th></tr>
      {subdomain_rows(sorted(subdomains))}
    </table>
  </div>
</div>

<!-- HIGH-VALUE TARGETS TAB -->
<div id="tab-targets" class="tab-pane">
  <div class="section">
    <h2>🎯 High-Value Targets</h2>
    {''.join(f'<div class="finding-card"><div class="finding-url">{esc(line)}</div></div>' for line in hv_targets[:50])
      if hv_targets else '<div class="no-findings">No high-value targets identified.</div>'}
  </div>
  <div class="section">
    <h2>🔍 Interesting Endpoints</h2>
    {''.join(f'<div class="finding-card"><div class="finding-url"><a href="{esc(u)}" target="_blank">{esc(u)}</a></div></div>' for u in interesting[:100])
      if interesting else '<div class="no-findings">No interesting endpoints flagged.</div>'}
  </div>
</div>

<!-- OPEN PORTS TAB -->
<div id="tab-ports" class="tab-pane">
  <div class="section">
    <h2>🔌 Open Ports & Services</h2>
    {"<table><tr><th>Host:Port</th><th>Service</th></tr>" + nmap_rows() + "</table>"
      if nmap_summary else '<div class="no-findings">No port scan data. Run with -m scan.</div>'}
  </div>
</div>

<!-- TECH STACK TAB -->
<div id="tab-tech" class="tab-pane">
  <div class="section">
    <h2>⚙️ Technology Stack</h2>
    <div class="tech-grid">
      {''.join(tech_badge(t, c) for t, c in top_techs) if top_techs else '<span class="muted">No tech data collected yet.</span>'}
    </div>
  </div>
</div>

<!-- NEW ASSETS TAB -->
<div id="tab-newassets" class="tab-pane">
  <div class="section">
    <h2>✨ New Assets Discovered ({len(new_ever)})</h2>
    {'<table><tr><th>New Subdomain</th></tr>' + subdomain_rows(sorted(new_ever)) + '</table>'
      if new_ever else '<div class="no-findings">No new assets recorded yet (first run baseline).</div>'}
  </div>
  {f"""<div class="section">
    <h2>🔄 Last Diff</h2>
    <p style="color:var(--muted);margin-bottom:12px">Timestamp: {esc(diff_data.get('timestamp',''))}</p>
    <h3 style="color:var(--green);margin-bottom:8px">New (+{len(diff_data.get('new',[]))})</h3>
    <table><tr><th>Subdomain</th></tr>{''.join(f"<tr><td><code>{esc(s)}</code> <span class='new-badge'>NEW</span></td></tr>" for s in diff_data.get('new',[]))}</table>
  </div>""" if diff_data.get('new') else ''}
</div>

</div><!-- /container -->

<script>
function showTab(name) {{
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  event.target.classList.add('active');
}}
</script>
</body>
</html>"""

# Write output
report_path = f"{OUTDIR}/reports/report.html"
os.makedirs(f"{OUTDIR}/reports", exist_ok=True)
with open(report_path, "w") as fh:
    fh.write(html)

print(f"[OK] Report generated: {report_path}")
